
export function PaddlingCaptain(props: Record<string, unknown>) {
  return (
    <div data-stub="PaddlingCaptain" style={{ padding: "2rem", border: "2px dashed #666", borderRadius: "0.5rem", color: "#999", textAlign: "center", fontSize: "0.875rem" }}>
      [PaddlingCaptain]
    </div>
  );
}
export default PaddlingCaptain;
