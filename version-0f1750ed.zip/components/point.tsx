
export function Point(props: Record<string, unknown>) {
  return (
    <div data-stub="Point" style={{ padding: "2rem", border: "2px dashed #666", borderRadius: "0.5rem", color: "#999", textAlign: "center", fontSize: "0.875rem" }}>
      [Point]
    </div>
  );
}
export default Point;
