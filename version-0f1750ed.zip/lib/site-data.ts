export const siteConfig = {
  name: "Kapten Krabbas Surfskola",
  shortName: "Kapten Krabba",
  description:
    "Kapten Krabbas Surfskola i Tylösand erbjuder lekfulla surfkurser för nybörjare och vågsugna. Ring eller mejla oss för att hitta rätt kurs.",
  url: "https://kaptenkrabbasurfskola.se",
  phoneDisplay: "070-415 64 83",
  phoneHref: "tel:+46704156483",
  email: "ahoj@kaptenkrabbasurfskola.se",
  emailHref: "mailto:ahoj@kaptenkrabbasurfskola.se",
  location: "Tylösand, Halmstad",
  keywords: [
    "Kapten Krabbas Surfskola",
    "surfskola Tylösand",
    "surfkurs Halmstad",
    "surfing nybörjare Tylösand",
    "privat surflektion Tylösand",
    "surfkurs Sverige",
  ],
} as const;

export const primaryNav = [
  { label: "Hem", href: "/" },
  { label: "Kurser", href: "/#kurser" },
  { label: "Besättningen", href: "/#besattningen" },
  { label: "Vanliga frågor", href: "/#faq" },
  { label: "Support", href: "/support" },
] as const;

const toDataUri = (svg: string) =>
  `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;

export const heroIllustration = toDataUri(`
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 960 720" fill="none">
    <defs>
      <linearGradient id="sky" x1="120" y1="60" x2="820" y2="620" gradientUnits="userSpaceOnUse">
        <stop stop-color="#FFF7EA"/>
        <stop offset="0.52" stop-color="#F2E1C3"/>
        <stop offset="1" stop-color="#D7EDF7"/>
      </linearGradient>
      <linearGradient id="wave1" x1="0" y1="440" x2="960" y2="620" gradientUnits="userSpaceOnUse">
        <stop stop-color="#5BAED6"/>
        <stop offset="1" stop-color="#0E5E8C"/>
      </linearGradient>
      <linearGradient id="wave2" x1="0" y1="520" x2="960" y2="690" gradientUnits="userSpaceOnUse">
        <stop stop-color="#77C6E7"/>
        <stop offset="1" stop-color="#1971A2"/>
      </linearGradient>
      <linearGradient id="board" x1="480" y1="250" x2="620" y2="360" gradientUnits="userSpaceOnUse">
        <stop stop-color="#F47C8B"/>
        <stop offset="1" stop-color="#F7B2BB"/>
      </linearGradient>
    </defs>
    <rect width="960" height="720" rx="48" fill="url(#sky)"/>
    <circle cx="786" cy="170" r="84" fill="#F47C8B" fill-opacity=".16"/>
    <circle cx="758" cy="146" r="58" fill="#FFE4C6"/>
    <path d="M0 438C116 390 206 394 308 430C432 475 538 474 654 434C774 392 846 400 960 438V720H0V438Z" fill="url(#wave1)"/>
    <path d="M0 534C118 492 206 496 310 530C422 567 562 567 674 526C782 486 870 490 960 520V720H0V534Z" fill="url(#wave2)"/>
    <path d="M90 325C162 282 220 280 284 320C349 360 410 359 474 317" stroke="#0E5E8C" stroke-opacity=".14" stroke-width="12" stroke-linecap="round"/>
    <path d="M228 292C245 273 270 263 300 268C333 273 352 296 372 314" stroke="#F47C8B" stroke-opacity=".25" stroke-width="10" stroke-linecap="round"/>
    <g transform="translate(420 196)">
      <ellipse cx="120" cy="159" rx="129" ry="44" fill="#0E5E8C" fill-opacity=".12"/>
      <path d="M112 86C146 86 170 113 170 146V152C170 190 145 214 112 214C79 214 54 190 54 152V146C54 113 78 86 112 86Z" fill="#F3C7A2"/>
      <path d="M52 144C52 103 78 70 118 70C154 70 179 94 184 130C175 118 160 112 146 112C138 112 132 114 124 119C105 130 87 136 52 144Z" fill="#17384C"/>
      <path d="M88 166C92 170 98 173 106 173C114 173 120 170 124 166" stroke="#17384C" stroke-width="6" stroke-linecap="round"/>
      <circle cx="90" cy="149" r="4.5" fill="#17384C"/>
      <circle cx="129" cy="149" r="4.5" fill="#17384C"/>
      <path d="M61 228C75 207 96 198 120 198C144 198 166 207 182 228V306H61V228Z" fill="#0E5E8C"/>
      <rect x="150" y="110" width="54" height="222" rx="27" transform="rotate(16 150 110)" fill="url(#board)"/>
      <path d="M171 138L185 306" stroke="#FFFFFF" stroke-opacity=".36" stroke-width="4" stroke-linecap="round"/>
      <path d="M33 287C89 282 164 296 220 332" stroke="#0E5E8C" stroke-opacity=".3" stroke-width="8" stroke-linecap="round"/>
    </g>
    <rect x="52" y="54" width="186" height="54" rx="27" fill="#FFFFFF" fill-opacity=".7"/>
    <circle cx="87" cy="81" r="10" fill="#0E5E8C"/>
    <rect x="108" y="74" width="96" height="14" rx="7" fill="#0E5E8C" fill-opacity=".16"/>
    <rect x="208" y="74" width="18" height="14" rx="7" fill="#F47C8B"/>
  </svg>
`);

const createPortrait = ({
  background,
  shirt,
  hair,
  board,
  accent,
}: {
  background: string;
  shirt: string;
  hair: string;
  board: string;
  accent: string;
}) =>
  toDataUri(`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640" fill="none">
      <defs>
        <linearGradient id="bg" x1="90" y1="40" x2="560" y2="620" gradientUnits="userSpaceOnUse">
          <stop stop-color="#FFF8EE"/>
          <stop offset="1" stop-color="${background}"/>
        </linearGradient>
      </defs>
      <rect width="640" height="640" rx="36" fill="url(#bg)"/>
      <circle cx="468" cy="138" r="88" fill="${accent}" fill-opacity=".18"/>
      <circle cx="146" cy="156" r="52" fill="#0E5E8C" fill-opacity=".08"/>
      <rect x="372" y="122" width="116" height="334" rx="58" transform="rotate(10 372 122)" fill="${board}"/>
      <path d="M430 148L462 430" stroke="#FFFFFF" stroke-opacity=".42" stroke-width="5" stroke-linecap="round"/>
      <ellipse cx="310" cy="516" rx="170" ry="44" fill="#0E5E8C" fill-opacity=".1"/>
      <circle cx="282" cy="214" r="72" fill="#F3C7A2"/>
      <path d="M206 214C206 162 244 126 289 126C335 126 371 160 371 208C332 200 300 180 280 154C264 182 238 201 206 214Z" fill="${hair}"/>
      <circle cx="256" cy="214" r="5.5" fill="#17384C"/>
      <circle cx="312" cy="214" r="5.5" fill="#17384C"/>
      <path d="M254 254C264 264 278 270 294 270C310 270 325 264 334 254" stroke="#17384C" stroke-width="7" stroke-linecap="round"/>
      <path d="M210 334C230 296 265 278 308 278C351 278 387 296 410 334V476H210V334Z" fill="${shirt}"/>
      <path d="M214 348C252 330 297 320 338 324C366 326 389 334 410 348" stroke="#FFFFFF" stroke-opacity=".28" stroke-width="6" stroke-linecap="round"/>
      <path d="M170 468C218 452 262 444 315 444C376 444 432 458 476 484" stroke="#0E5E8C" stroke-opacity=".18" stroke-width="10" stroke-linecap="round"/>
    </svg>
  `);

export const crewPortraits = {
  kapten: createPortrait({
    background: "#D9EDF4",
    shirt: "#0E5E8C",
    hair: "#18384D",
    board: "#F47C8B",
    accent: "#F47C8B",
  }),
  maja: createPortrait({
    background: "#F5E8D0",
    shirt: "#F47C8B",
    hair: "#335C69",
    board: "#70BDD9",
    accent: "#0E5E8C",
  }),
  olle: createPortrait({
    background: "#E6F2F6",
    shirt: "#2A7AA9",
    hair: "#0E5E8C",
    board: "#F2C27D",
    accent: "#F47C8B",
  }),
} as const;