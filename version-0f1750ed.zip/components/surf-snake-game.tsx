"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import React from "react";
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUp, Pause, Play, RotateCcw, Waves } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";





type Point = {
    x: number;
    y: number;
};
type Direction = "up" | "down" | "left" | "right";
const GRID_SIZE = 12;
const INITIAL_SNAKE: Point[] = [
    { x: 3, y: 6 },
    { x: 2, y: 6 },
    { x: 1, y: 6 },
];
export const OPPOSITES: Record<Direction, Direction> = {
    up: "down",
    down: "up",
    left: "right",
    right: "left",
};
function createWave(excluded: Point[]) {
    const occupied = new Set(excluded.map((segment) => `${segment.x}-${segment.y}`));
    while (true) {
        const point = {
            x: Math.floor(Math.random() * GRID_SIZE),
            y: Math.floor(Math.random() * GRID_SIZE),
        };
        if (!occupied.has(`${point.x}-${point.y}`)) {
            return point;
        }
    }
}
function movePoint(point: Point, direction: Direction) {
    switch (direction) {
        case "up":
            return { x: point.x, y: (point.y - 1 + GRID_SIZE) % GRID_SIZE };
        case "down":
            return { x: point.x, y: (point.y + 1) % GRID_SIZE };
        case "left":
            return { x: (point.x - 1 + GRID_SIZE) % GRID_SIZE, y: point.y };
        case "right":
            return { x: (point.x + 1) % GRID_SIZE, y: point.y };
    }
}
export function SurfSnakeGame() {
    const boardRef = useRef<HTMLDivElement>(null);
    const directionRef = useRef<Direction>("right");
    const [snake, setSnake] = useState<Point[]>(INITIAL_SNAKE);
    const [wave, setWave] = useState<Point>(() => createWave(INITIAL_SNAKE));
    const [direction, setDirection] = useState<Direction>("right");
    const [score, setScore] = useState(0);
    const [playing, setPlaying] = useState(false);
    const [gameOver, setGameOver] = useState(false);
    useEffect(() => {
        directionRef.current = direction;
    }, [direction]);
    const resetGame = (startImmediately = false) => {
        directionRef.current = "right";
        setDirection("right");
        setSnake(INITIAL_SNAKE);
        setWave(createWave(INITIAL_SNAKE));
        setScore(0);
        setGameOver(false);
        setPlaying(startImmediately);
        window.requestAnimationFrame(() => {
            boardRef.current?.focus();
        });
    };
    const turn = (nextDirection: Direction) => {
        if (OPPOSITES[directionRef.current] === nextDirection) {
            return;
        }
        directionRef.current = nextDirection;
        setDirection(nextDirection);
    };
    useEffect(() => {
        if (!playing || gameOver) {
            return;
        }
        const timer = window.setInterval(() => {
            setSnake((currentSnake) => {
                const currentHead = currentSnake[0];
                const nextHead = movePoint(currentHead, directionRef.current);
                const collision = currentSnake.some((segment) => segment.x === nextHead.x && segment.y === nextHead.y);
                if (collision) {
                    setPlaying(false);
                    setGameOver(true);
                    return currentSnake;
                }
                const foundWave = nextHead.x === wave.x && nextHead.y === wave.y;
                const nextSnake = [nextHead, ...currentSnake];
                if (foundWave) {
                    setScore((currentScore) => currentScore + 1);
                    setWave(createWave(nextSnake));
                }
                else {
                    nextSnake.pop();
                }
                return nextSnake;
            });
        }, 180);
        return () => {
            window.clearInterval(timer);
        };
    }, [gameOver, playing, wave]);
    const handleKeyDown = (event: React.KeyboardEvent<HTMLDivElement>) => {
        if (event.key === "ArrowUp" || event.key === "w" || event.key === "W") {
            event.preventDefault();
            turn("up");
        }
        if (event.key === "ArrowDown" || event.key === "s" || event.key === "S") {
            event.preventDefault();
            turn("down");
        }
        if (event.key === "ArrowLeft" || event.key === "a" || event.key === "A") {
            event.preventDefault();
            turn("left");
        }
        if (event.key === "ArrowRight" || event.key === "d" || event.key === "D") {
            event.preventDefault();
            turn("right");
        }
        if (event.key === " " || event.key === "Enter") {
            event.preventDefault();
            if (gameOver) {
                resetGame(true);
            }
            else {
                setPlaying((current) => !current);
            }
        }
    };
    const snakeCells = useMemo(() => new Set(snake.map((segment) => `${segment.x}-${segment.y}`)), [snake]);
    const headKey = `${snake[0].x}-${snake[0].y}`;
    const waveKey = `${wave.x}-${wave.y}`;
    const statusText = gameOver
        ? "Kapsejsat — tryck på starta om och ge dig ut igen."
        : playing
            ? "På väg över brädet."
            : "Ligger vid bryggan och väntar på start.";
    return (<Card className="sea-panel overflow-hidden rounded-[1.5rem] border-0">
      <CardHeader className="gap-4 pb-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
          <div className="space-y-2">
            <Badge className="w-fit rounded-full border-primary/15 bg-primary/10 px-3 py-1 text-primary">
              Mini-spel • Surf-snake
            </Badge>
            <CardTitle className="font-display text-2xl tracking-tight sm:text-3xl">
              Plocka vågor, undvik din egen svallvåg
            </CardTitle>
            <CardDescription className="max-w-2xl text-sm leading-6 text-muted-foreground sm:text-base">
              Styr surfaren med piltangenter eller knapparna. Spelet är litet,
              lättsamt och helt valfritt — ungefär som en extra tur till kiosken efter passet.
            </CardDescription>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <Badge className="rounded-full border-primary/15 bg-background/80 px-3 py-1 text-foreground">
              Poäng: {score}
            </Badge>
            <Badge className="rounded-full border-primary/15 bg-background/80 px-3 py-1 text-foreground">
              {playing ? "I fart" : gameOver ? "Kapsejsad" : "I hamn"}
            </Badge>
          </div>
        </div>
      </CardHeader>

      <CardContent className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_20rem]">
        <div className="space-y-4">
          <div ref={boardRef} tabIndex={0} onKeyDown={handleKeyDown} aria-label="Surf-snake-spel. Använd piltangenter eller WASD för att styra. Tryck mellanslag för att pausa eller starta." className="soft-grid grid grid-cols-12 gap-1 rounded-[1.5rem] border border-primary/10 bg-background/70 p-3 shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
            {Array.from({ length: GRID_SIZE * GRID_SIZE }).map((_, index) => {
            const x = index % GRID_SIZE;
            const y = Math.floor(index / GRID_SIZE);
            const key = `${x}-${y}`;
            const isHead = key === headKey;
            const isSnake = snakeCells.has(key);
            const isWave = key === waveKey;
            return (<div key={key} aria-hidden="true" className={`aspect-square rounded-[0.55rem] transition-all duration-150 ${isHead
                    ? "board-cell board-cell--head"
                    : isSnake
                        ? "board-cell board-cell--snake"
                        : isWave
                            ? "board-cell board-cell--wave"
                            : "board-cell"}`}/>);
        })}
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <Button type="button" onClick={() => {
            if (gameOver) {
                resetGame(true);
                return;
            }
            setPlaying((current) => !current);
            window.requestAnimationFrame(() => {
                boardRef.current?.focus();
            });
        }} className="h-11 rounded-full px-5 shadow-lg shadow-primary/20">
              {playing ? (<>
                  <Pause className="mr-2 h-4 w-4"/>
                  Pausa
                </>) : (<>
                  <Play className="mr-2 h-4 w-4"/>
                  {gameOver ? "Segla igen" : "Starta"}
                </>)}
            </Button>

            <Button type="button" variant="outline" onClick={() => resetGame(false)} className="h-11 rounded-full border-primary/15 bg-background/80 px-5">
              <RotateCcw className="mr-2 h-4 w-4"/>
              Starta om
            </Button>

            <a href="#sidfot" className="text-sm font-medium text-muted-foreground underline-offset-4 transition-colors duration-200 hover:text-foreground hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
              Hoppa över spelet
            </a>
          </div>
        </div>

        <div className="space-y-4 rounded-[1.5rem] border border-primary/10 bg-background/72 p-4 shadow-sm">
          <div className="space-y-2">
            <p className="text-xs font-semibold uppercase tracking-[0.22em] text-primary/80">
              Ombordinstruktion
            </p>
            <p className="text-sm leading-6 text-muted-foreground">
              Samla korallfärgade vågor, undvik att korsa din egen surfsvans och håll kursen stadig.
            </p>
          </div>

          <div className="rounded-[1.25rem] bg-secondary/60 p-4">
            <div className="flex items-center gap-2 text-sm font-medium text-foreground">
              <Waves className="h-4 w-4 text-primary"/>
              Status från däck
            </div>
            <p className="mt-2 text-sm leading-6 text-muted-foreground">{statusText}</p>
          </div>

          <div className="grid grid-cols-3 gap-2">
            <div />
            <Button type="button" variant="outline" onClick={() => turn("up")} className="h-11 rounded-[1rem] border-primary/15 bg-background/80" aria-label="Styr uppåt">
              <ArrowUp className="h-4 w-4"/>
            </Button>
            <div />
            <Button type="button" variant="outline" onClick={() => turn("left")} className="h-11 rounded-[1rem] border-primary/15 bg-background/80" aria-label="Styr vänster">
              <ArrowLeft className="h-4 w-4"/>
            </Button>
            <Button type="button" variant="outline" onClick={() => turn("down")} className="h-11 rounded-[1rem] border-primary/15 bg-background/80" aria-label="Styr nedåt">
              <ArrowDown className="h-4 w-4"/>
            </Button>
            <Button type="button" variant="outline" onClick={() => turn("right")} className="h-11 rounded-[1rem] border-primary/15 bg-background/80" aria-label="Styr höger">
              <ArrowRight className="h-4 w-4"/>
            </Button>
          </div>

          <p aria-live="polite" className="sr-only">
            Poäng {score}. {statusText}
          </p>
        </div>
      </CardContent>
    </Card>);
}
export default SurfSnakeGame;