export default function Loading() {
  return (
    <div
      role="status"
      aria-live="polite"
      className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8"
    >
      <div className="grid gap-8 lg:grid-cols-[1fr_1fr]">
        <div className="space-y-4">
          <div className="h-9 w-36 animate-pulse rounded-full bg-primary/10" />
          <div className="h-16 w-full max-w-2xl animate-pulse rounded-[1.5rem] bg-primary/10" />
          <div className="h-24 w-full max-w-xl animate-pulse rounded-[1.5rem] bg-primary/10" />
        </div>
        <div className="h-80 animate-pulse rounded-[1.5rem] bg-background/70 shadow-sm" />
      </div>

      <div className="mt-8 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <div className="h-52 animate-pulse rounded-[1.5rem] bg-background/70 shadow-sm" />
        <div className="h-52 animate-pulse rounded-[1.5rem] bg-background/70 shadow-sm" />
        <div className="h-52 animate-pulse rounded-[1.5rem] bg-background/70 shadow-sm" />
        <div className="h-52 animate-pulse rounded-[1.5rem] bg-background/70 shadow-sm" />
      </div>

      <p className="sr-only">Laddar supporten.</p>
    </div>
  );
}