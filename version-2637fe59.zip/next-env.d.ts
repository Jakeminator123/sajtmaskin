/// <reference types="next" />
/// <reference types="next/image-types/global" />

// This file is maintained by Next.js — do not edit manually.
