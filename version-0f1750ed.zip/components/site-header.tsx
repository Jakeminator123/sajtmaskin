"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { LifeBuoy, Menu, Phone, Ship as ShipWheel } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetClose,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { primaryNav, siteConfig } from "@/lib/site-data";

export function SiteHeader() {
  const pathname = usePathname();

  const isActive = (href: string) => {
    if (href === "/") {
      return pathname === "/";
    }

    if (href === "/support") {
      return pathname === "/support";
    }

    return pathname === "/" && href.startsWith("/#");
  };

  return (
    <header className="sticky top-0 z-50 border-b border-white/50 bg-background/78 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6 lg:px-8">
        <Link
          href="/"
          className="group inline-flex items-center gap-3 rounded-full focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          <div className="flex h-11 w-11 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg shadow-primary/20 transition-transform duration-200 group-hover:scale-[1.03] group-active:scale-95">
            <ShipWheel className="h-5 w-5" />
          </div>
          <div className="flex flex-col">
            <span className="font-display text-sm font-semibold tracking-tight text-foreground sm:text-base">
              {siteConfig.name}
            </span>
            <span className="text-xs text-muted-foreground">
              Tylösand med saltstänk i tonen
            </span>
          </div>
        </Link>

        <nav aria-label="Huvudnavigering" className="hidden items-center gap-1 md:flex">
          {primaryNav.map((item) => {
            const active = isActive(item.href);

            return (
              <Link
                key={item.href}
                href={item.href}
                className={`rounded-full px-4 py-2 text-sm font-medium transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${
                  active
                    ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20"
                    : "text-foreground/80 hover:bg-white/70 hover:text-foreground"
                }`}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="hidden items-center gap-3 md:flex">
          <Badge className="rounded-full border-primary/15 bg-primary/10 px-3 py-1 text-primary">
            Tylösand
          </Badge>
          <Button asChild className="h-11 rounded-full px-5 shadow-lg shadow-primary/20">
            <a href={siteConfig.phoneHref}>
              <Phone className="mr-2 h-4 w-4" />
              Ring oss
            </a>
          </Button>
        </div>

        <div className="flex items-center gap-2 md:hidden">
          <Button asChild variant="outline" className="h-11 rounded-full border-primary/15 bg-background/80 px-4">
            <a href={siteConfig.phoneHref} aria-label={`Ring ${siteConfig.name}`}>
              <Phone className="h-4 w-4" />
            </a>
          </Button>

          <Sheet>
            <SheetTrigger asChild>
              <Button
                type="button"
                variant="outline"
                className="h-11 rounded-full border-primary/15 bg-background/80 px-4"
                aria-label="Öppna meny"
              >
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent
              side="right"
              className="w-[90vw] max-w-sm border-l border-primary/10 bg-background/98 px-6"
            >
              <SheetHeader className="mb-8 text-left">
                <SheetTitle className="font-display text-xl text-foreground">
                  Ombordmeny
                </SheetTitle>
                <SheetDescription className="text-sm text-muted-foreground">
                  Genvägar till kurser, frågor och support utan att gå på grund.
                </SheetDescription>
              </SheetHeader>

              <div className="space-y-2">
                {primaryNav.map((item) => {
                  const active = isActive(item.href);

                  return (
                    <SheetClose asChild key={item.href}>
                      <Link
                        href={item.href}
                        className={`flex items-center justify-between rounded-[1.5rem] px-4 py-3 text-base font-medium transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${
                          active
                            ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20"
                            : "sea-panel text-foreground hover:translate-x-1"
                        }`}
                      >
                        <span>{item.label}</span>
                        {item.href === "/support" ? (
                          <LifeBuoy className="h-4 w-4" />
                        ) : (
                          <ShipWheel className="h-4 w-4" />
                        )}
                      </Link>
                    </SheetClose>
                  );
                })}
              </div>

              <div className="mt-8 rounded-[1.5rem] border border-primary/15 bg-background/70 p-4 shadow-sm">
                <p className="text-xs font-semibold uppercase tracking-[0.22em] text-primary/80">
                  Direktkontakt
                </p>
                <p className="mt-2 text-sm leading-6 text-muted-foreground">
                  Vi svarar gärna på allt från första popupen till gruppupplägg för hela kompisgänget.
                </p>
                <Button asChild className="mt-4 h-11 w-full rounded-full">
                  <a href={siteConfig.phoneHref}>
                    <Phone className="mr-2 h-4 w-4" />
                    {siteConfig.phoneDisplay}
                  </a>
                </Button>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}

export default SiteHeader;
