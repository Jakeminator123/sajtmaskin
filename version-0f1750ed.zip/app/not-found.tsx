
import { Anchor, ArrowLeft, LifeBuoy } from "lucide-react";
import { Button } from "@/components/ui/button"
import Link from "next/link"



export default function NotFound() {
  return (
    <div className="px-4 py-16 sm:px-6 lg:px-8">
      <div className="sea-panel mx-auto max-w-2xl rounded-[1.5rem] border-0 p-8 text-center sm:p-10">
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-primary/10 text-primary">
          <Anchor className="h-6 w-6" />
        </div>
        <h1 className="font-display mt-6 text-3xl font-semibold tracking-tight sm:text-4xl">
          Den sidan drev visst ut till havs
        </h1>
        <p className="mt-4 text-base leading-7 text-muted-foreground">
          Vi hittar inte sidan du letar efter. Men lugn — besättningen hjälper dig gärna tillbaka till rätt brygga.
        </p>
        <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:justify-center">
          <Button asChild className="h-11 rounded-full px-6">
            <Link href="/">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Till startsidan
            </Link>
          </Button>
          <Button asChild variant="outline" className="h-11 rounded-full border-primary/15 bg-background/80 px-6">
            <Link href="/support">
              <LifeBuoy className="mr-2 h-4 w-4" />
              Gå till support
            </Link>
          </Button>
        </div>
      </div>
    </div>
  );
}