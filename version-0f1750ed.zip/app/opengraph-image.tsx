import { ImageResponse } from "next/og";
import { siteConfig } from "@/lib/site-data";
// next/og not available in preview



export const size = {
  width: 1200,
  height: 630,
};

export const contentType = "image/png";

export default function OpenGraphImage() {
  return new ImageResponse(
    (
      <div
        style={{
          alignItems: "stretch",
          background:
            "linear-gradient(135deg, #f7f1e5 0%, #f2e7d2 48%, #dbedf5 100%)",
          display: "flex",
          height: "100%",
          justifyContent: "space-between",
          overflow: "hidden",
          position: "relative",
          width: "100%",
        }}
      >
        <div
          style={{
            background:
              "radial-gradient(circle at top left, rgba(14,94,140,0.22), transparent 34%), radial-gradient(circle at bottom right, rgba(244,124,139,0.18), transparent 32%)",
            inset: 0,
            position: "absolute",
          }}
        />
        <div
          style={{
            display: "flex",
            flex: 1,
            flexDirection: "column",
            justifyContent: "center",
            padding: "64px 72px",
            position: "relative",
          }}
        >
          <div
            style={{
              alignItems: "center",
              background: "rgba(255,255,255,0.72)",
              border: "1px solid rgba(14,94,140,0.12)",
              borderRadius: "999px",
              color: "#0e5e8c",
              display: "flex",
              fontSize: 26,
              fontWeight: 700,
              gap: 12,
              padding: "14px 22px",
              width: "fit-content",
            }}
          >
            Tylösand • Surfskola
          </div>

          <div
            style={{
              color: "#17384c",
              display: "flex",
              flexDirection: "column",
              fontSize: 72,
              fontWeight: 800,
              letterSpacing: "-0.04em",
              lineHeight: 1,
              marginTop: 28,
              maxWidth: 680,
            }}
          >
            Tämj Kattegatts vågor
          </div>

          <div
            style={{
              color: "#4f6471",
              display: "flex",
              fontSize: 30,
              lineHeight: 1.35,
              marginTop: 24,
              maxWidth: 760,
            }}
          >
            Lekfulla surfkurser för nybörjare, små grupper och vågsugna semesterfirare.
          </div>

          <div
            style={{
              alignItems: "center",
              color: "#17384c",
              display: "flex",
              fontSize: 24,
              gap: 16,
              marginTop: 36,
            }}
          >
            <span>{siteConfig.name}</span>
            <span style={{ color: "#f47c8b" }}>•</span>
            <span>{siteConfig.phoneDisplay}</span>
          </div>
        </div>

        <div
          style={{
            display: "flex",
            padding: "58px 62px 58px 0",
            position: "relative",
            width: 360,
          }}
        >
          <div
            style={{
              background: "rgba(255,255,255,0.74)",
              border: "1px solid rgba(14,94,140,0.12)",
              borderRadius: 30,
              boxShadow: "0 30px 60px rgba(14,94,140,0.15)",
              display: "flex",
              flex: 1,
              flexDirection: "column",
              justifyContent: "space-between",
              overflow: "hidden",
              padding: 22,
              transform: "rotate(4deg)",
            }}
          >
            <div
              style={{
                borderRadius: 22,
                display: "flex",
                flex: 1,
                overflow: "hidden",
                background:
                  "linear-gradient(180deg, #fff6ea 0%, #d9edf4 54%, #0e5e8c 54.1%, #6ebedf 100%)",
                position: "relative",
              }}
            >
              <div
                style={{
                  background: "rgba(244,124,139,0.16)",
                  borderRadius: 999,
                  height: 84,
                  position: "absolute",
                  right: 34,
                  top: 32,
                  width: 84,
                }}
              />
              <div
                style={{
                  background: "#ffe5c4",
                  borderRadius: 999,
                  height: 56,
                  position: "absolute",
                  right: 48,
                  top: 46,
                  width: 56,
                }}
              />
              <div
                style={{
                  background: "#f47c8b",
                  borderRadius: 999,
                  height: 210,
                  position: "absolute",
                  right: 98,
                  top: 132,
                  transform: "rotate(16deg)",
                  width: 72,
                }}
              />
              <div
                style={{
                  background: "#f3c7a2",
                  borderRadius: 999,
                  height: 76,
                  left: 130,
                  position: "absolute",
                  top: 128,
                  width: 76,
                }}
              />
              <div
                style={{
                  background: "#17384c",
                  borderRadius: "40px 40px 24px 24px",
                  height: 70,
                  left: 120,
                  position: "absolute",
                  top: 92,
                  width: 94,
                }}
              />
              <div
                style={{
                  background: "#0e5e8c",
                  borderRadius: 26,
                  height: 128,
                  left: 108,
                  position: "absolute",
                  top: 198,
                  width: 120,
                }}
              />
            </div>

            <div
              style={{
                color: "#17384c",
                display: "flex",
                flexDirection: "column",
                gap: 10,
                marginTop: 18,
              }}
            >
              <div style={{ fontSize: 24, fontWeight: 700 }}>Nybörjare ombord</div>
              <div style={{ color: "#5b6d78", fontSize: 18, lineHeight: 1.35 }}>
                Små grupper, trygg pepp och surf med varm ton.
              </div>
            </div>
          </div>
        </div>
      </div>
    ),
    size,
  );
}