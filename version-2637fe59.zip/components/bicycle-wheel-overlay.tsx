"use client";

import { Float } from "@react-three/drei";
import { useFrame } from "@react-three/fiber";
import { useRef } from "react";
import type { Group as ThreeGroup } from "three";
import { ThreeCanvasShell } from "@/components/three-canvas-shell";
import { useReducedMotion } from "@/hooks/use-reduced-motion";

export default function WheelMesh({ reducedMotion }: { reducedMotion: boolean }) {
  const wheelRef = useRef<ThreeGroup | null>(null);

  useFrame((state, delta) => {
    if (!wheelRef.current) return;

    if (reducedMotion) {
      wheelRef.current.rotation.x = 0.35;
      wheelRef.current.rotation.y = 0.45;
      return;
    }

    const t = state.clock.elapsedTime;
    wheelRef.current.rotation.z += delta * 2.4;
    wheelRef.current.rotation.x = 0.28 + Math.sin(t * 0.7) * 0.18;
    wheelRef.current.rotation.y = 0.35 + Math.sin(t * 0.45) * 0.35;
  });

  return (
    <group ref={wheelRef}>
      <mesh castShadow receiveShadow>
        <torusGeometry args={[0.95, 0.12, 32, 180]} />
        <meshStandardMaterial color="#111827" roughness={0.7} metalness={0.15} />
      </mesh>

      <mesh castShadow receiveShadow>
        <torusGeometry args={[0.79, 0.035, 20, 160]} />
        <meshStandardMaterial color="#e4ecf9" roughness={0.25} metalness={0.9} />
      </mesh>

      {Array.from({ length: 20 }).map((_, index) => {
        const angle = (index / 20) * Math.PI * 2;
        return (
          <mesh key={`spoke-${index}`} rotation={[0, 0, angle]}>
            <boxGeometry args={[0.012, 1.58, 0.012]} />
            <meshStandardMaterial color="#f8fafc" metalness={0.85} roughness={0.2} />
          </mesh>
        );
      })}

      <mesh castShadow>
        <cylinderGeometry args={[0.12, 0.12, 0.24, 28]} />
        <meshStandardMaterial color="#d7a626" metalness={0.85} roughness={0.3} />
      </mesh>

      <mesh rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.026, 0.026, 0.9, 20]} />
        <meshStandardMaterial color="#cbd5e1" metalness={0.95} roughness={0.15} />
      </mesh>
    </group>
  );
}

export function BicycleWheelOverlay() {
  const reducedMotion = useReducedMotion();

  return (
    <div className="pointer-events-none fixed bottom-20 right-2 z-40 h-36 w-36 sm:bottom-6 sm:right-6 sm:h-52 sm:w-52 lg:h-60 lg:w-60">
      <ThreeCanvasShell
        className="h-full w-full overflow-hidden rounded-full border border-border/70 bg-card/40 shadow-lg shadow-black/20 backdrop-blur-sm"
        ariaLabel="Ett tredimensionellt cykelhjul som snurrar över sidan"
        fallback={
          <div className="relative h-full w-full rounded-full border border-border/80 bg-background/80">
            <div className="absolute inset-2 rounded-full border-[5px] border-primary/50" />
            <div className="absolute inset-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-accent" />
            <div className="absolute inset-0 animate-pulse rounded-full bg-primary/5 motion-reduce:animate-none" />
          </div>
        }
        decorative={false}
        cameraPosition={[0, 0, 3.1]}
        cameraFov={34}
      >
        <ambientLight intensity={0.75} />
        <directionalLight position={[2.5, 2.2, 2.8]} intensity={1.2} color="#ffffff" />
        <pointLight position={[-2.2, -1.8, 2]} intensity={0.55} color="#ffcc73" />
        <Float
          speed={reducedMotion ? 0 : 1}
          rotationIntensity={reducedMotion ? 0 : 0.25}
          floatIntensity={reducedMotion ? 0 : 0.15}
        >
          <WheelMesh reducedMotion={reducedMotion} />
        </Float>
      </ThreeCanvasShell>
    </div>
  );
}