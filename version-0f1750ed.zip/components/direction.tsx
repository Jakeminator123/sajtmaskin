
export function Direction(props: Record<string, unknown>) {
  return (
    <div data-stub="Direction" style={{ padding: "2rem", border: "2px dashed #666", borderRadius: "0.5rem", color: "#999", textAlign: "center", fontSize: "0.875rem" }}>
      [Direction]
    </div>
  );
}
export default Direction;
