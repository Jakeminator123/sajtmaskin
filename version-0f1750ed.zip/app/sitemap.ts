import { siteConfig } from "@/lib/site-data";
import type { MetadataRoute } from "next";




export default function sitemap(): MetadataRoute.Sitemap {
  const lastModified = new Date();

  return [
    {
      url: siteConfig.url,
      lastModified,
      changeFrequency: "weekly",
      priority: 1,
    },
    {
      url: `${siteConfig.url}/support`,
      lastModified,
      changeFrequency: "monthly",
      priority: 0.8,
    },
  ];
}