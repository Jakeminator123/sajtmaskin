
import { ArrowUpRight, Mail, MapPin, Phone, Ship as ShipWheel } from "lucide-react";
import Link from "next/link"
import { primaryNav, siteConfig } from "@/lib/site-data";



export function SiteFooter() {
  const year = new Date().getFullYear();

  return (
    <footer id="sidfot" className="px-4 pb-8 pt-6 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="sea-panel rounded-[1.5rem] px-6 py-8 sm:px-8 sm:py-10">
          <div className="grid gap-10 lg:grid-cols-[1.1fr_0.8fr_0.8fr]">
            <div className="space-y-4">
              <div className="inline-flex items-center gap-3">
                <div className="flex h-11 w-11 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg shadow-primary/20">
                  <ShipWheel className="h-5 w-5" />
                </div>
                <div>
                  <p className="font-display text-lg font-semibold tracking-tight">
                    {siteConfig.name}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Surflektioner i Tylösand för nybörjare, små grupper och vågsugna semesterfirare.
                  </p>
                </div>
              </div>
              <p className="max-w-md text-sm leading-7 text-muted-foreground">
                Vi lär ut surf med lugn hand, kvick humor och lagom mycket kaptenston.
                Ring innan vinden vänder, så styr vi upp rätt kurs.
              </p>
            </div>

            <div className="space-y-4">
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-primary/80">
                Navigera
              </p>
              <div className="space-y-2">
                {primaryNav.map((item) => (
                  <Link
                    key={item.href}
                    href={item.href}
                    className="group inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors duration-200 hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    {item.label}
                    <ArrowUpRight className="h-4 w-4 opacity-0 transition-opacity duration-200 group-hover:opacity-100" />
                  </Link>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-primary/80">
                Kontakt
              </p>
              <div className="space-y-3 text-sm text-muted-foreground">
                <a
                  href={siteConfig.phoneHref}
                  className="inline-flex items-center gap-2 transition-colors duration-200 hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                >
                  <Phone className="h-4 w-4 text-primary" />
                  {siteConfig.phoneDisplay}
                </a>
                <a
                  href={siteConfig.emailHref}
                  className="inline-flex items-center gap-2 transition-colors duration-200 hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                >
                  <Mail className="h-4 w-4 text-primary" />
                  {siteConfig.email}
                </a>
                <p className="inline-flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-primary" />
                  {siteConfig.location}
                </p>
              </div>
            </div>
          </div>

          <div className="mt-8 flex flex-col gap-3 border-t border-primary/10 pt-6 text-sm text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
            <p>© {year} {siteConfig.name}. Alla landkrabbor välkomna ombord.</p>
            <p>Byggd för saltstänk, nybörjarleenden och bättre sjöben.</p>
          </div>
        </div>
      </div>
    </footer>
  );
}

export default SiteFooter;
