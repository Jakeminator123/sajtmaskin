import { Metadata } from "next";
import { Inter, Sora } from "next/font/google";
import type { ReactNode } from "react";
import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";
import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-sans",
});

const sora = Sora({
  subsets: ["latin"],
  variable: "--font-display",
});

export const metadata: Metadata = {
  title: {
    default: "Hem | Pingpong",
    template: "%s | Pingpong",
  },
  description:
    "Upptäck varför pingpong är en rolig och tillgänglig sport, lär dig grunderna och kom igång med att spela.",
  keywords: [
    "pingpong",
    "bordtennis",
    "börja spela pingpong",
    "pingpong regler",
    "pingpong för nybörjare",
    "spela bordtennis",
  ],
  openGraph: {
    title: "Hem | Pingpong",
    description:
      "Upptäck varför pingpong är en rolig och tillgänglig sport, lär dig grunderna och kom igång med att spela.",
    url: "https://example.com",
    siteName: "Pingpong",
    locale: "sv_SE",
    type: "website",
  },
};

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "WebSite",
  name: "Pingpong",
  inLanguage: "sv-SE",
  description:
    "En lekfull och tydlig sajt som introducerar pingpong, varför det är kul och hur man kommer igång.",
  url: "https://example.com",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="sv">
      <body className={`${inter.variable} ${sora.variable} min-h-screen bg-background text-foreground`}>
        <SiteHeader />
        <main>{children}</main>
        <SiteFooter />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
      </body>
    </html>
  );
}