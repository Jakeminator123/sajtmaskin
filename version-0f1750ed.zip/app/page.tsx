import Image from "next/image";
import Link from "next/link";

import {
  Anchor,
  ArrowRight,
  Compass,
  LifeBuoy,
  Mail,
  MapPin,
  Phone,
  ShieldCheck,
  Sparkles,
  Star,
  Waves,
  Wind,
} from "lucide-react";

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { SurfSnakeGame } from "@/components/surf-snake-game";
import { crewPortraits, heroIllustration, siteConfig } from "@/lib/site-data";

const proofStats = [
  {
    value: "4.9/5",
    label: "Snitt från sommargäster som kom hit med pirr i magen och gick hem med mer sjöben.",
    icon: Star,
  },
  {
    value: "8 pers",
    label: "Max i Nybörjarbris så att ingen behöver känna sig som ensam matros i storm.",
    icon: Anchor,
  },
  {
    value: "Allt ombord",
    label: "Bräda och våtdräkt samt trygg guidning ingår. Du tar med handduk och gott humör.",
    icon: ShieldCheck,
  },
] as const;

const packages = [
  {
    title: "Nybörjarbris",
    eyebrow: "Trygg start",
    description:
      "För dig som vill prova surfing utan att kasta dig rakt in i dramatiken. Vi går igenom balans, popup och hur du läser de snällare vågorna.",
    bullets: [
      "Perfekt första pass i små grupper",
      "Fokus på trygg start och surfglädje",
      "Bräda och våtdräkt ingår",
    ],
    microcopy: "Ingen tidigare loggbok krävs — bara nyfikenhet och torra ombyten.",
    icon: Wind,
    highlighted: false,
  },
  {
    title: "Stormjagare",
    eyebrow: "Lite mer fart",
    description:
      "För dig som redan blivit vän med brädan och vill vässa teknik, timing och mod när dyningen börjar få lite mer personlighet.",
    bullets: [
      "Mer teknik, mer fart och mer vågläsning",
      "Tips kring linjeval, tempo och popup under tryck",
      "Passar dig som vill bygga vidare snabbt",
    ],
    microcopy: "Vi jagar inte storm för stormens skull — bara bättre känsla i varje sväng.",
    icon: Waves,
    highlighted: true,
  },
  {
    title: "Privatlektion med Kaptenen själv",
    eyebrow: "Skräddarsytt",
    description:
      "Ett personligt upplägg med Kapten Krabba vid rodret. Vi formar passet efter din nivå, ditt mod och hur mycket pepp du vill ha i örat.",
    bullets: [
      "Personlig coaching hela vägen",
      "Fokus på just dina utmaningar",
      "Perfekt för privat upplägg eller liten duo",
    ],
    microcopy: "Kaptenen håller kursen stadig och snacket lagom salt.",
    icon: Compass,
    highlighted: false,
  },
] as const;

const crew = [
  {
    name: "Kapten Krabba",
    role: "Grundare & huvudkapten",
    bio: "Skolans karismatiska ledare som kan prata om vindriktning med samma entusiasm som andra pratar om semesterlunch.",
    detail: "Kul detalj: säger ibland “håll kursen” även när han pekar mot glasskiosken.",
    image: crewPortraits.kapten,
    alt: "Illustrerat porträtt av Kapten Krabba med surfbräda.",
  },
  {
    name: "Maja “Sjöstjärna” Holm",
    role: "Instruktör & nybörjartryggare",
    bio: "Pedagogisk, lugn och mästare på att göra första popupen mindre dramatisk än den känns i huvudet.",
    detail: "Kul detalj: har en nästan magisk tajming för att säga “du har det” precis när man faktiskt har det.",
    image: crewPortraits.maja,
    alt: "Illustrerat porträtt av Maja Sjöstjärna Holm med surfbräda.",
  },
  {
    name: "Olle “Dyning” Ek",
    role: "Tekniknörd & balanslots",
    bio: "Har lugn energi, skarpa ögon för timing och kan förklara surfteknik utan att det låter som fysikprov på stranden.",
    detail: "Kul detalj: noterar gärna hur varje våg känns som om han förde en egen sjöjournal.",
    image: crewPortraits.olle,
    alt: "Illustrerat porträtt av Olle Dyning Ek med surfbräda.",
  },
] as const;

const faqs = [
  {
    question: "Behöver jag ha surfat tidigare?",
    answer:
      "Nej, nybörjare är varmt välkomna. Vi har gott om tålamod, tydliga instruktioner och noll krav på att du redan ska se ut som en surfkatalog.",
  },
  {
    question: "Vad ska jag ta med mig?",
    answer:
      "Ta med badkläder, handduk, energi och ett gott humör. Resten brukar vi kunna ordna utan att du behöver släpa halva båthuset till stranden.",
  },
  {
    question: "Blir lektionen av om vädret är stökigt?",
    answer:
      "Vi anpassar efter hav och säkerhet, och kaptenen avgör kursen. Ibland betyder det full surf, ibland ett smartare upplägg — alltid med tryggheten först.",
  },
  {
    question: "Kan jag kontakta er för grupp eller privat upplägg?",
    answer:
      "Ja, ring eller mejla så styr vi upp något passande. Små kompisgäng, företagsutflykter och privatlektioner går fint att prata ihop.",
  },
] as const;

export default function HomePage() {
  return (
    <div className="relative overflow-hidden">
      <section className="relative px-4 pb-8 pt-10 sm:px-6 sm:pb-12 sm:pt-14 lg:px-8 lg:pt-20">
        <div className="hero-halo pointer-events-none absolute inset-x-0 top-10 z-0 mx-auto h-[28rem] max-w-6xl rounded-full" />
        <div className="relative z-10 mx-auto max-w-7xl">
          <div className="grid items-center gap-10 lg:grid-cols-[1.02fr_0.98fr] lg:gap-14">
            <div className="space-y-6" data-animate data-delay="1">
              <Badge className="rounded-full border-primary/15 bg-background/80 px-4 py-2 text-primary shadow-sm">
                <Waves className="mr-2 h-4 w-4" />
                Tylösand • landkrabbor välkomna ombord
              </Badge>

              <div className="space-y-4">
                <p className="text-xs font-semibold uppercase tracking-[0.28em] text-primary/75">
                  Kapten Krabbas Surfskola
                </p>
                <h1 className="font-display text-4xl font-semibold tracking-tight text-balance sm:text-5xl lg:text-6xl">
                  Tämj{" "}
                  <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                    Kattegatts vågor
                  </span>{" "}
                  med lugn guide, lekfull ton och sand mellan tårna.
                </h1>
                <p className="max-w-2xl text-lg leading-8 text-muted-foreground sm:text-xl">
                  Vi håller surflektioner i Tylösand för nybörjare, semesterfirare och små
                  grupper som vill prova något roligare än ännu en glass i motvind.
                  Här får du trygg coaching, tydlig pepp och lagom mycket sjöfartssnack.
                </p>
              </div>

              <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
                <Button
                  asChild
                  className="h-12 rounded-full px-6 text-base shadow-lg shadow-primary/20 transition-all duration-200 hover:scale-[1.02] active:scale-95"
                >
                  <a href={siteConfig.phoneHref}>
                    <Phone className="mr-2 h-5 w-5" />
                    Ring oss
                  </a>
                </Button>

                <a
                  href={siteConfig.emailHref}
                  className="inline-flex items-center gap-2 text-sm font-semibold text-foreground transition-colors duration-200 hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                >
                  Mejla besättningen
                  <ArrowRight className="h-4 w-4" />
                </a>
              </div>

              <p className="text-sm leading-6 text-muted-foreground">
                Ingen skeppsexamen krävs. Vi tar hand om första vågen även om dina sjöben
                fortfarande är lite teoretiska.
              </p>

              <div className="flex flex-wrap gap-3" data-stagger>
                <div className="sea-chip rounded-full px-4 py-2 text-sm font-medium text-foreground">
                  Små grupper
                </div>
                <div className="sea-chip rounded-full px-4 py-2 text-sm font-medium text-foreground">
                  Våtdräkt och bräda ombord
                </div>
                <div className="sea-chip rounded-full px-4 py-2 text-sm font-medium text-foreground">
                  Direktkontakt via telefon eller mejl
                </div>
              </div>
            </div>

            <div className="relative" data-animate data-delay="2">
              <div className="absolute -inset-5 rounded-[2rem] bg-[radial-gradient(circle_at_70%_20%,rgba(244,124,139,0.22),transparent_34%),radial-gradient(circle_at_20%_80%,rgba(14,94,140,0.18),transparent_30%)] blur-2xl" />
              <Card className="sea-panel relative overflow-hidden rounded-[1.5rem] border-0 md:rotate-[2deg]">
                <CardContent className="grid gap-4 p-4 sm:p-5">
                  <div className="overflow-hidden rounded-[1.5rem] border border-primary/10 bg-background/75">
                    <Image
                      src={heroIllustration}
                      alt="Illustration av surfare på våg i Tylösand med varm sommarkänsla."
                      width={960}
                      height={720}
                      priority
                      className="h-auto w-full"
                    />
                  </div>

                  <div className="grid gap-3 sm:grid-cols-2">
                    <div className="rounded-[1.25rem] border border-primary/10 bg-background/78 p-4 shadow-sm">
                      <p className="text-xs font-semibold uppercase tracking-[0.22em] text-primary/80">
                        Dagens sjörapport
                      </p>
                      <p className="mt-2 text-lg font-semibold tracking-tight text-foreground">
                        Snäll dyning, gott läge för första svängen
                      </p>
                      <p className="mt-2 text-sm leading-6 text-muted-foreground">
                        Tylösand brukar bjuda på fina nybörjarvågor när vinden sköter sig.
                      </p>
                    </div>

                    <div className="rounded-[1.25rem] bg-primary px-4 py-4 text-primary-foreground shadow-lg shadow-primary/20">
                      <p className="text-xs font-semibold uppercase tracking-[0.22em] text-primary-foreground/80">
                        Ombord just nu
                      </p>
                      <div className="mt-3 space-y-2 text-sm">
                        <div className="flex items-center justify-between gap-3 rounded-full bg-background/10 px-3 py-2">
                          <span>Nybörjare</span>
                          <span className="font-semibold">välkomna</span>
                        </div>
                        <div className="flex items-center justify-between gap-3 rounded-full bg-background/10 px-3 py-2">
                          <span>Gruppstorlek</span>
                          <span className="font-semibold">max 8</span>
                        </div>
                        <div className="flex items-center justify-between gap-3 rounded-full bg-background/10 px-3 py-2">
                          <span>Kaptenston</span>
                          <span className="font-semibold">lagom salt</span>
                        </div>
                      </div>
                    </div>

                    <div className="rounded-[1.25rem] border border-primary/10 bg-secondary/65 p-4 shadow-sm sm:col-span-2">
                      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                        <div>
                          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-primary/80">
                            Behöver du mer info?
                          </p>
                          <p className="mt-2 text-sm leading-6 text-muted-foreground">
                            Frågor om väder, utrustning eller privat upplägg? Vår supportsida håller kursen.
                          </p>
                        </div>
                        <Button
                          asChild
                          variant="outline"
                          className="h-11 rounded-full border-primary/15 bg-background/80 px-5"
                        >
                          <Link href="/support">
                            <LifeBuoy className="mr-2 h-4 w-4" />
                            Till support
                          </Link>
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-8 grid gap-4 md:grid-cols-3" data-stagger>
            {proofStats.map((item) => (
              <Card
                key={item.label}
                className="sea-panel rounded-[1.5rem] border-0 transition-all duration-200 hover:-translate-y-1 hover:shadow-lg"
              >
                <CardContent className="flex h-full gap-4 p-5">
                  <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                    <item.icon className="h-5 w-5" />
                  </div>
                  <div className="space-y-1">
                    <p className="font-display text-2xl font-semibold tracking-tight text-foreground">
                      {item.value}
                    </p>
                    <p className="text-sm leading-6 text-muted-foreground">{item.label}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section id="kurser" className="px-4 py-12 sm:px-6 sm:py-16 lg:px-8 lg:py-20">
        <div className="mx-auto max-w-7xl">
          <div className="max-w-3xl space-y-4" data-animate>
            <Badge className="rounded-full border-primary/15 bg-primary/10 px-4 py-2 text-primary">
              Våra kurspaket
            </Badge>
            <h2 className="font-display text-3xl font-semibold tracking-tight text-balance sm:text-4xl lg:text-5xl">
              Tre kurser för tre sorters vågsug
            </h2>
            <p className="text-lg leading-8 text-muted-foreground">
              Oavsett om du vill prova första gången, bygga vidare eller få full fokus av kaptenen
              själv har vi ett upplägg som känns personligt, tydligt och faktiskt kul.
            </p>
          </div>

          <div className="mt-8 grid gap-5 lg:grid-cols-3" data-stagger>
            {packages.map((item) => (
              <Card
                key={item.title}
                className={`overflow-hidden rounded-[1.5rem] border-0 transition-all duration-200 hover:-translate-y-1 hover:shadow-xl ${
                  item.highlighted
                    ? "sea-panel-strong text-primary-foreground lg:-translate-y-3"
                    : "sea-panel"
                }`}
              >
                <CardHeader className="space-y-4 pb-4">
                  <div className="flex items-start justify-between gap-4">
                    <Badge
                      className={`rounded-full px-3 py-1 ${
                        item.highlighted
                          ? "border-white/20 bg-white/12 text-primary-foreground"
                          : "border-primary/15 bg-primary/10 text-primary"
                      }`}
                    >
                      {item.eyebrow}
                    </Badge>
                    <div
                      className={`flex h-12 w-12 items-center justify-center rounded-full ${
                        item.highlighted
                          ? "bg-white/12 text-primary-foreground"
                          : "bg-primary/10 text-primary"
                      }`}
                    >
                      <item.icon className="h-5 w-5" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <CardTitle className="font-display text-2xl tracking-tight">
                      {item.title}
                    </CardTitle>
                    <CardDescription
                      className={
                        item.highlighted
                          ? "text-primary-foreground/82"
                          : "text-muted-foreground"
                      }
                    >
                      {item.description}
                    </CardDescription>
                  </div>
                </CardHeader>

                <CardContent className="space-y-5">
                  <ul className="space-y-3">
                    {item.bullets.map((bullet) => (
                      <li key={bullet} className="flex items-start gap-3 text-sm leading-6">
                        <Sparkles
                          className={`mt-0.5 h-4 w-4 shrink-0 ${
                            item.highlighted ? "text-primary-foreground" : "text-accent"
                          }`}
                        />
                        <span>{bullet}</span>
                      </li>
                    ))}
                  </ul>

                  <div
                    className={`rounded-[1.25rem] p-4 text-sm leading-6 ${
                      item.highlighted
                        ? "bg-white/10 text-primary-foreground/90"
                        : "bg-secondary/55 text-muted-foreground"
                    }`}
                  >
                    {item.microcopy}
                  </div>

                  <Button
                    asChild
                    variant={item.highlighted ? "secondary" : "outline"}
                    className={`h-11 w-full rounded-full ${
                      item.highlighted
                        ? "bg-white text-primary hover:bg-white/90"
                        : "border-primary/15 bg-white/80"
                    }`}
                  >
                    <a href={siteConfig.phoneHref}>Ring om {item.title}</a>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section
        id="besattningen"
        className="px-4 py-12 sm:px-6 sm:py-16 lg:px-8 lg:py-20"
      >
        <div className="mx-auto grid max-w-7xl gap-8 lg:grid-cols-[0.88fr_1.12fr] lg:items-start">
          <div className="space-y-5" data-animate>
            <Badge className="rounded-full border-primary/15 bg-background/80 px-4 py-2 text-primary">
              Möt besättningen
            </Badge>
            <h2 className="font-display text-3xl font-semibold tracking-tight text-balance sm:text-4xl">
              Trygga instruktörer med personlighet, pepp och koll på dyningen
            </h2>
            <p className="text-lg leading-8 text-muted-foreground">
              Vi är en liten besättning som gillar tydlig vägledning, avslappnad stämning och
              surfpass där du faktiskt känner att du lär dig något — inte bara blir blöt med stil.
            </p>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="sea-panel rounded-[1.5rem] p-5">
                <p className="text-xs font-semibold uppercase tracking-[0.22em] text-primary/80">
                  Vår stil
                </p>
                <p className="mt-2 text-sm leading-6 text-muted-foreground">
                  Personlig coaching, små grupper och noll behov av att spela cool på stranden.
                </p>
              </div>
              <div className="sea-panel rounded-[1.5rem] p-5">
                <p className="text-xs font-semibold uppercase tracking-[0.22em] text-primary/80">
                  Vårt löfte
                </p>
                <p className="mt-2 text-sm leading-6 text-muted-foreground">
                  Vi håller tonen lätt, instruktionerna tydliga och säkerheten först — kaptenens ord.
                </p>
              </div>
            </div>
          </div>

          <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3" data-stagger>
            {crew.map((member) => (
              <Card
                key={member.name}
                className="sea-panel overflow-hidden rounded-[1.5rem] border-0 transition-all duration-200 hover:-translate-y-1 hover:shadow-xl"
              >
                <div className="border-b border-primary/10 bg-background/60 p-4">
                  <Image
                    src={member.image}
                    alt={member.alt}
                    width={640}
                    height={640}
                    className="h-auto w-full rounded-[1.25rem]"
                  />
                </div>
                <CardHeader className="space-y-2 pb-3">
                  <CardTitle className="font-display text-2xl tracking-tight">
                    {member.name}
                  </CardTitle>
                  <CardDescription className="text-primary">{member.role}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm leading-6 text-muted-foreground">{member.bio}</p>
                  <div className="rounded-[1.25rem] bg-secondary/55 p-4 text-sm leading-6 text-muted-foreground">
                    {member.detail}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section id="faq" className="px-4 py-12 sm:px-6 sm:py-16 lg:px-8 lg:py-20">
        <div className="mx-auto grid max-w-7xl gap-8 lg:grid-cols-[1.08fr_0.92fr]">
          <div className="space-y-5" data-animate>
            <Badge className="rounded-full border-primary/15 bg-primary/10 px-4 py-2 text-primary">
              Vanliga frågor från däck
            </Badge>
            <h2 className="font-display text-3xl font-semibold tracking-tight text-balance sm:text-4xl">
              Snabba svar innan du tar första steget ut i skummet
            </h2>
            <p className="text-lg leading-8 text-muted-foreground">
              Exakt fyra frågor dyker upp mest. Här kommer de, serverade utan sjökortsbilagor.
            </p>

            <Card className="sea-panel rounded-[1.5rem] border-0">
              <CardContent className="p-2 sm:p-3">
                <Accordion type="single" collapsible className="w-full">
                  {faqs.map((item) => (
                    <AccordionItem
                      key={item.question}
                      value={item.question}
                      className="rounded-[1.25rem] border-0 px-3"
                    >
                      <AccordionTrigger className="text-left text-base font-medium hover:no-underline">
                        {item.question}
                      </AccordionTrigger>
                      <AccordionContent className="pb-4 pr-2 text-sm leading-7 text-muted-foreground">
                        {item.answer}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-5" data-stagger>
            <Card className="sea-panel rounded-[1.5rem] border-0">
              <CardHeader>
                <Badge className="w-fit rounded-full border-primary/15 bg-background/80 px-3 py-1 text-primary">
                  Support ombord
                </Badge>
                <CardTitle className="font-display text-2xl tracking-tight">
                  Behöver du lite mer sjöklar vägledning?
                </CardTitle>
                <CardDescription>
                  På supportsidan hittar du fler svar om utrustning, väder, grupper och hur du hittar rätt på stranden.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button asChild className="h-11 w-full rounded-full">
                  <Link href="/support">
                    <LifeBuoy className="mr-2 h-4 w-4" />
                    Öppna support
                  </Link>
                </Button>
                <div className="rounded-[1.25rem] bg-secondary/55 p-4">
                  <ul className="space-y-3 text-sm leading-6 text-muted-foreground">
                    <li className="flex gap-3">
                      <Sparkles className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
                      Vad du ska ta med dig
                    </li>
                    <li className="flex gap-3">
                      <Sparkles className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
                      Hur vi tänker kring väder och säkerhet
                    </li>
                    <li className="flex gap-3">
                      <Sparkles className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
                      Grupp- och privatupplägg
                    </li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card className="sea-panel-strong rounded-[1.5rem] border-0 text-primary-foreground">
              <CardHeader>
                <CardTitle className="font-display text-2xl tracking-tight">
                  Ring eller mejla från närmaste brygga
                </CardTitle>
                <CardDescription className="text-primary-foreground/80">
                  Det är våra enda CTAs av en enkel anledning: direkt kontakt är snabbast när man ska styra upp rätt pass.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <a
                  href={siteConfig.phoneHref}
                  className="flex items-center gap-3 rounded-[1.25rem] bg-background/12 px-4 py-3 transition-colors duration-200 hover:bg-background/16 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
                >
                  <Phone className="h-4 w-4" />
                  {siteConfig.phoneDisplay}
                </a>
                <a
                  href={siteConfig.emailHref}
                  className="flex items-center gap-3 rounded-[1.25rem] bg-background/12 px-4 py-3 transition-colors duration-200 hover:bg-background/16 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
                >
                  <Mail className="h-4 w-4" />
                  {siteConfig.email}
                </a>
                <div className="flex items-center gap-3 rounded-[1.25rem] bg-background/12 px-4 py-3">
                  <MapPin className="h-4 w-4" />
                  {siteConfig.location}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section id="kontakt" className="px-4 py-12 sm:px-6 sm:py-16 lg:px-8 lg:py-20">
        <div className="mx-auto max-w-7xl" data-animate>
          <div className="sea-panel-strong rounded-[1.5rem] px-6 py-8 text-primary-foreground sm:px-8 sm:py-10 lg:px-10">
            <div className="grid gap-8 lg:grid-cols-[1fr_auto] lg:items-center">
              <div className="space-y-4">
                <Badge className="rounded-full border-white/20 bg-background/10 px-4 py-2 text-primary-foreground">
                  Kontakt
                </Badge>
                <h2 className="font-display text-3xl font-semibold tracking-tight text-balance sm:text-4xl lg:text-5xl">
                  Ge oss en signal innan vinden vänder
                </h2>
                <p className="max-w-2xl text-lg leading-8 text-primary-foreground/85">
                  Vill du hitta rätt kurs, fråga om gruppupplägg eller bara känna efter om surf
                  verkligen är din grej? Ring oss eller mejla. Vi svarar varmt, tydligt och utan att göra en hel expedition av det.
                </p>
              </div>

              <div className="grid gap-3 sm:min-w-[18rem]">
                <Button
                  asChild
                  className="h-12 rounded-full bg-background px-6 text-base text-primary shadow-xl shadow-black/10 hover:bg-background/92"
                >
                  <a href={siteConfig.phoneHref}>
                    <Phone className="mr-2 h-5 w-5" />
                    Ring oss
                  </a>
                </Button>
                <Button
                  asChild
                  variant="secondary"
                  className="h-12 rounded-full bg-background/12 px-6 text-base text-primary-foreground hover:bg-background/16"
                >
                  <a href={siteConfig.emailHref}>
                    <Mail className="mr-2 h-5 w-5" />
                    Mejla besättningen
                  </a>
                </Button>
              </div>
            </div>

            <div className="mt-8 grid gap-4 border-t border-white/15 pt-6 sm:grid-cols-3" data-stagger>
              <div className="rounded-[1.25rem] bg-background/10 p-4">
                <p className="text-xs font-semibold uppercase tracking-[0.22em] text-primary-foreground/75">
                  Telefon
                </p>
                <p className="mt-2 text-lg font-semibold tracking-tight">
                  {siteConfig.phoneDisplay}
                </p>
              </div>
              <div className="rounded-[1.25rem] bg-background/10 p-4">
                <p className="text-xs font-semibold uppercase tracking-[0.22em] text-primary-foreground/75">
                  Mejladress
                </p>
                <p className="mt-2 text-lg font-semibold tracking-tight break-words">
                  {siteConfig.email}
                </p>
              </div>
              <div className="rounded-[1.25rem] bg-background/10 p-4">
                <p className="text-xs font-semibold uppercase tracking-[0.22em] text-primary-foreground/75">
                  Plats
                </p>
                <p className="mt-2 text-lg font-semibold tracking-tight">
                  {siteConfig.location}
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="spel" className="px-4 pb-2 pt-4 sm:px-6 sm:pb-4 lg:px-8 lg:pb-6">
        <div className="mx-auto max-w-7xl space-y-4">
          <div className="max-w-2xl space-y-3" data-animate>
            <Badge className="rounded-full border-primary/15 bg-background/80 px-4 py-2 text-primary">
              Sista lilla vågen
            </Badge>
            <h2 className="font-display text-2xl font-semibold tracking-tight sm:text-3xl">
              En liten surf-sväng innan du går i land
            </h2>
            <p className="text-base leading-7 text-muted-foreground">
              Mest för nöjes skull, minst lika mycket för stämningen. Hoppa in om du vill —
              eller scrolla vidare till sidfoten som en värdig kapten.
            </p>
          </div>

          <SurfSnakeGame />
        </div>
      </section>

      <section id="input-demo" className="px-4 py-16 md:py-24 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="rounded-[1.75rem] bg-black px-6 py-8 text-white shadow-2xl shadow-black/30 transition-all duration-200 sm:px-8 sm:py-10 lg:px-10">
            <div className="grid gap-8 lg:grid-cols-[0.9fr_1.1fr] lg:items-start">
              <div className="space-y-4">
                <Badge className="rounded-full border-white/15 bg-background/10 px-4 py-2 text-white">
                  Ny Input-komponent
                </Badge>
                <h2 className="font-display text-3xl font-semibold tracking-tight text-balance sm:text-4xl">
                  Stort, svart och längst upp i den här sektionen
                </h2>
                <p className="max-w-2xl text-base leading-7 text-white/70 sm:text-lg">
                  Här syns den nya shadcn/ui-komponenten Input som ett tydligt demoinslag längst ner på sidan,
                  men placerad överst i sin egen svarta yta för maximal kontrast och en lite mer appig känsla.
                </p>
              </div>

              <div className="space-y-3">
                <label
                  htmlFor="input-demo"
                  className="block text-sm font-semibold uppercase tracking-[0.22em] text-white/70"
                >
                  Skriv till kaptenen
                </label>
                <Input
                  id="input-demo"
                  aria-label="Skriv en fråga till Kapten Krabbas surfskola"
                  type="text"
                  placeholder="Till exempel: Har ni plats i Nybörjarbris på lördag?"
                  className="h-16 rounded-[1.25rem] border-white/15 bg-background/8 px-5 text-lg text-white placeholder:text-white/45 focus-visible:border-white/40 focus-visible:ring-white/25"
                />
                <p className="text-sm leading-6 text-white/60">
                  Demo för komponenten Input — fortfarande samma raka kurs: ring oss eller mejla när du vill få svar på riktigt.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}