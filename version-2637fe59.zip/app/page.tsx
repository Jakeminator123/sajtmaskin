import Image from "next/image";
import Link from "next/link";
import {
  ArrowRight,
  Sparkles,
  CheckCircle,
  BadgeCheck,
  Info,
  Trophy,
  Clock3,
  Handshake,
  Users,
  Zap,
} from "lucide-react";
import { BicycleWheelOverlay } from "@/components/bicycle-wheel-overlay";
import { Reveal } from "@/components/reveal";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import type { LucideIcon } from "lucide-react";

type Benefit = {
  title: string;
  description: string;
  icon: LucideIcon;
};

type Equipment = {
  name: string;
  detail: string;
  tip: string;
};

const benefits: Benefit[] = [
  {
    title: "Bättre reflexer",
    description: "Snabba dueller tränar reaktionsförmåga och precision utan att kännas som hård träning.",
    icon: Zap,
  },
  {
    title: "Socialt och inkluderande",
    description: "Alla kan vara med, oavsett ålder eller nivå. Perfekt för familj, kompisar och kollegor.",
    icon: Users,
  },
  {
    title: "Kul på många platser",
    description: "Spela hemma, i skolan, på fritidsgården eller i klubb — pingpong funkar nästan överallt.",
    icon: Handshake,
  },
];

const equipment: Equipment[] = [
  {
    name: "Bord och nät",
    detail: "Ett stabilt bord med tydliga linjer och ett nät i rätt höjd är grunden för bra spel.",
    tip: "Tips: Har du begränsat utrymme? Fällbara bord gör det lätt att komma igång hemma.",
  },
  {
    name: "Racket och bollar",
    detail: "Ett nybörjarracket med bra kontroll och några 40+ bollar räcker långt i starten.",
    tip: "Tips: Välj bollar med 3 stjärnor för jämn studs när du tränar teknik.",
  },
  {
    name: "Yta att röra sig på",
    detail: "Lämna plats runt bordet så du kan ta steg i sidled och nå snabba returer.",
    tip: "Tips: Minst 1,5 meter bakom varje kortsida gör stor skillnad för flytet.",
  },
];

const rules = [
  {
    title: "Serve och första boll",
    content:
      "Serven ska studsa en gång på din sida och en gång på motståndarens sida. Vid dubbel ska serven gå diagonalt. Ett tydligt kast uppåt gör serven lättare att läsa och lära.",
  },
  {
    title: "Poängräkning i pingpong",
    content:
      "Ett set spelas vanligtvis till 11 poäng, med minst två poängs skillnad. Efter varannan serve byter spelarna vem som servar. Vid 10–10 fortsätter ni tills någon leder med två.",
  },
  {
    title: "Träning vs match",
    content:
      "På träning fokuserar du på teknik, fotarbete och repetition. I match handlar det mer om rytm, taktik och att våga variera tempo, skruv och placering.",
  },
];

const gallery = [
  {
    src: "https://images.unsplash.com/photo-1560012057-4372e14c5085?auto=format&fit=crop&w=1400&q=80",
    alt: "Två spelare i rörelse vid ett pingpongbord i ljus sporthall",
    caption: "Action och fokus i varje bollväxling",
  },
  {
    src: "https://images.unsplash.com/photo-1543353071-10c8ba85a904?auto=format&fit=crop&w=1400&q=80",
    alt: "Närbild på pingpongracket och boll på bordets kant",
    caption: "Små detaljer gör stor skillnad",
  },
  {
    src: "https://images.unsplash.com/photo-1526676037777-05a232554f77?auto=format&fit=crop&w=1400&q=80",
    alt: "Vänner som spelar avslappnat pingpong inomhus",
    caption: "Spela för glädjen tillsammans",
  },
  {
    src: "https://images.unsplash.com/photo-1587280501635-68a0e82cd5ff?auto=format&fit=crop&w=1400&q=80",
    alt: "Ungdomar som tränar pingpong med coach i klubbmiljö",
    caption: "Från nybörjare till trygg spelare",
  },
];

export default function HomePage() {
  return (
    <div className="pb-24 sm:pb-0">
      <section id="hem" className="relative overflow-hidden py-16 sm:py-24 lg:py-28">
        <div className="mx-auto grid w-full max-w-6xl gap-10 px-4 sm:px-6 lg:grid-cols-[1.05fr_0.95fr] lg:items-center lg:px-8">
          <Reveal className="space-y-8">
            <Badge className="rounded-full bg-accent/15 px-4 py-1.5 text-accent-foreground">
              Pingpong för nybörjare
            </Badge>

            <div className="space-y-5">
              <h1 className="max-w-2xl text-4xl font-bold tracking-tight text-foreground sm:text-5xl lg:text-6xl">
                Pingpong är snabbt, roligt och lätt att börja med.
              </h1>
              <p className="max-w-2xl text-lg leading-relaxed text-muted-foreground">
                Upptäck en sport med hög energi och låg tröskel. Du behöver inte vara proffs för att få fart, skratt
                och spelglädje från första rallyt.
              </p>
            </div>

            <div className="flex flex-col gap-3 sm:flex-row">
              <Button asChild size="lg" className="h-12 rounded-full px-8 text-base">
                <Link href="/#kom-igang">
                  Börja spela
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="h-12 rounded-full px-8 text-base">
                <Link href="/#regler">Lär dig grunderna</Link>
              </Button>
            </div>

            <div className="grid max-w-xl grid-cols-3 gap-3" data-stagger="1">
              <Card className="rounded-2xl border-border/80 bg-card/80">
                <CardContent className="p-4 text-center">
                  <p className="text-2xl font-semibold text-primary">11</p>
                  <p className="text-xs text-muted-foreground">poäng per set</p>
                </CardContent>
              </Card>
              <Card className="rounded-2xl border-border/80 bg-card/80">
                <CardContent className="p-4 text-center">
                  <p className="text-2xl font-semibold text-primary">2</p>
                  <p className="text-xs text-muted-foreground">spelare räcker</p>
                </CardContent>
              </Card>
              <Card className="rounded-2xl border-border/80 bg-card/80">
                <CardContent className="p-4 text-center">
                  <p className="text-2xl font-semibold text-primary">30 min</p>
                  <p className="text-xs text-muted-foreground">för att komma igång</p>
                </CardContent>
              </Card>
            </div>
          </Reveal>

          <Reveal delay={1} className="relative">
            <Card className="overflow-hidden rounded-3xl border-border/80 bg-card shadow-lg shadow-primary/10">
              <CardContent className="p-0">
                <Image
                  src="https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&w=1400&q=80"
                  alt="Person som slår en snabb forehand vid pingpongbord i ljus hall"
                  width={1400}
                  height={1000}
                  className="h-[420px] w-full object-cover sm:h-[500px]"
                  priority
                  unoptimized
                />
              </CardContent>
            </Card>
            <div className="absolute -left-3 top-8 rounded-full bg-accent px-4 py-2 text-sm font-semibold text-accent-foreground shadow-sm motion-safe:animate-bounce">
              Hög energi
            </div>
            <div className="absolute -bottom-4 right-4 rounded-2xl border border-border bg-background/95 px-4 py-3 shadow-sm">
              <p className="inline-flex items-center gap-2 text-sm font-medium text-foreground">
                <Sparkles className="h-4 w-4 text-accent" />
                Från första boll till riktig spelkänsla
              </p>
            </div>
          </Reveal>
        </div>
      </section>

      <section id="fordelar" className="py-16 sm:py-24">
        <div className="mx-auto w-full max-w-6xl px-4 sm:px-6 lg:px-8">
          <Reveal className="mb-10 max-w-2xl space-y-4">
            <Badge variant="secondary" className="rounded-full bg-primary/10 text-primary">
              Varför spela pingpong?
            </Badge>
            <h2 className="text-3xl font-semibold tracking-tight sm:text-4xl">
              Sportigt, socialt och alltid nära till spel
            </h2>
            <p className="text-lg text-muted-foreground">
              Pingpong ger pulshöjning utan krångel. Du får både koordination, fokus och glädje i samma aktivitet.
            </p>
          </Reveal>

          <div className="grid gap-4 md:grid-cols-3">
            {benefits.map((item, index) => {
              const Icon = item.icon;
              return (
                <Reveal key={item.title} delay={(index % 4) as 0 | 1 | 2 | 3}>
                  <Card className="h-full rounded-2xl border-border/80 bg-card transition-all duration-300 hover:-translate-y-1 hover:border-primary/20 hover:shadow-md">
                    <CardHeader className="space-y-3">
                      <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
                        <Icon className="h-5 w-5" />
                      </div>
                      <CardTitle className="text-xl">{item.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <CardDescription className="text-sm leading-relaxed text-muted-foreground">
                        {item.description}
                      </CardDescription>
                    </CardContent>
                  </Card>
                </Reveal>
              );
            })}
          </div>
        </div>
      </section>

      <section id="utrustning" className="bg-muted/55 py-16 sm:py-24">
        <div className="mx-auto grid w-full max-w-6xl gap-8 px-4 sm:px-6 lg:grid-cols-[0.9fr_1.1fr] lg:gap-10 lg:px-8">
          <Reveal className="space-y-5">
            <Badge className="rounded-full bg-accent/20 text-accent-foreground">Det här behöver du för att börja</Badge>
            <h2 className="text-3xl font-semibold tracking-tight sm:text-4xl">Enkel utrustning, snabb start</h2>
            <p className="text-lg leading-relaxed text-muted-foreground">
              Du behöver inte mycket för att spela bra och ha kul. Börja med grunderna och bygg vidare i din egen takt.
            </p>

            <Card className="rounded-2xl border-border/80 bg-card">
              <CardContent className="space-y-3 p-5">
                <p className="text-sm font-semibold text-foreground">Startchecklistan</p>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="inline-flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-primary" />
                    Bord med nät
                  </li>
                  <li className="inline-flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-primary" />2 racket + 3 bollar
                  </li>
                  <li className="inline-flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-primary" />
                    Fri yta runt bordet
                  </li>
                </ul>
              </CardContent>
            </Card>
          </Reveal>

          <TooltipProvider>
            <div className="grid gap-4">
              {equipment.map((item, index) => (
                <Reveal key={item.name} delay={(index % 4) as 0 | 1 | 2 | 3}>
                  <Card className="rounded-2xl border-border/80 bg-card transition-all duration-300 hover:border-primary/20 hover:shadow-md">
                    <CardContent className="p-5">
                      <div className="flex items-start justify-between gap-4">
                        <div className="space-y-2">
                          <p className="inline-flex items-center gap-2 text-base font-semibold text-foreground">
                            <BadgeCheck className="h-4 w-4 text-primary" />
                            {item.name}
                          </p>
                          <p className="text-sm leading-relaxed text-muted-foreground">{item.detail}</p>
                        </div>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <button
                              type="button"
                              aria-label={`Tips om ${item.name}`}
                              className="rounded-full p-2 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                            >
                              <Info className="h-4 w-4" />
                            </button>
                          </TooltipTrigger>
                          <TooltipContent className="max-w-56 rounded-xl bg-secondary text-secondary-foreground">
                            <p className="text-sm">{item.tip}</p>
                          </TooltipContent>
                        </Tooltip>
                      </div>
                    </CardContent>
                  </Card>
                </Reveal>
              ))}
            </div>
          </TooltipProvider>
        </div>
      </section>

      <section id="regler" className="py-16 sm:py-24">
        <div className="mx-auto grid w-full max-w-6xl gap-8 px-4 sm:px-6 lg:grid-cols-[1.05fr_0.95fr] lg:px-8">
          <Reveal className="space-y-4">
            <Badge variant="secondary" className="rounded-full bg-primary/10 text-primary">
              Så fungerar spelet
            </Badge>
            <h2 className="text-3xl font-semibold tracking-tight sm:text-4xl">Grundreglerna på ett enkelt sätt</h2>
            <p className="text-lg text-muted-foreground">
              Lär dig serven, poängsystemet och skillnaden mellan träning och matchspel. Det räcker för att börja spela
              med trygghet direkt.
            </p>

            <Card className="rounded-2xl border-border/80 bg-card">
              <CardContent className="space-y-3 p-5">
                <p className="inline-flex items-center gap-2 text-sm font-semibold text-foreground">
                  <Trophy className="h-4 w-4 text-accent" />
                  Snabb översikt
                </p>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="inline-flex items-center gap-2">
                    <Clock3 className="h-4 w-4 text-primary" />
                    Matchtempo byggs upp stegvis
                  </li>
                  <li className="inline-flex items-center gap-2">
                    <BadgeCheck className="h-4 w-4 text-primary" />
                    Fokus på kontroll först, fart sen
                  </li>
                </ul>
              </CardContent>
            </Card>
          </Reveal>

          <Reveal delay={1}>
            <Accordion type="single" collapsible className="w-full rounded-2xl border border-border/80 bg-card px-4">
              {rules.map((item, index) => (
                <AccordionItem key={item.title} value={`item-${index}`}>
                  <AccordionTrigger className="text-left text-base font-medium">{item.title}</AccordionTrigger>
                  <AccordionContent className="text-sm leading-relaxed text-muted-foreground">
                    {item.content}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </Reveal>
        </div>
      </section>

      <section id="galleri" className="bg-muted/50 py-16 sm:py-24">
        <div className="mx-auto w-full max-w-6xl px-4 sm:px-6 lg:px-8">
          <Reveal className="mb-10 max-w-2xl space-y-4">
            <Badge className="rounded-full bg-accent/20 text-accent-foreground">Känslan i sporten</Badge>
            <h2 className="text-3xl font-semibold tracking-tight sm:text-4xl">Action, precision och spelglädje</h2>
            <p className="text-lg text-muted-foreground">
              Från skarpa dueller till avslappnade matcher mellan vänner — pingpong passar alla miljöer.
            </p>
          </Reveal>

          <Reveal className="md:hidden">
            <Carousel opts={{ align: "start", loop: true }} className="w-full">
              <CarouselContent>
                {gallery.map((image) => (
                  <CarouselItem key={image.src} className="basis-[88%]">
                    <Card className="overflow-hidden rounded-2xl border-border/80 bg-card">
                      <CardContent className="space-y-3 p-0">
                        <Image
                          src={image.src}
                          alt={image.alt}
                          width={1200}
                          height={800}
                          className="h-64 w-full object-cover"
                          unoptimized
                        />
                        <p className="px-4 pb-4 text-sm text-muted-foreground">{image.caption}</p>
                      </CardContent>
                    </Card>
                  </CarouselItem>
                ))}
              </CarouselContent>
              <CarouselPrevious className="left-2" />
              <CarouselNext className="right-2" />
            </Carousel>
          </Reveal>

          <div className="hidden grid-cols-2 gap-4 md:grid">
            {gallery.map((image, index) => (
              <Reveal key={image.src} delay={(index % 4) as 0 | 1 | 2 | 3}>
                <Card className="overflow-hidden rounded-2xl border-border/80 bg-card transition-all duration-300 hover:-translate-y-1 hover:shadow-md">
                  <CardContent className="space-y-3 p-0">
                    <Image
                      src={image.src}
                      alt={image.alt}
                      width={1200}
                      height={800}
                      className="h-60 w-full object-cover"
                      unoptimized
                    />
                    <p className="px-4 pb-4 text-sm text-muted-foreground">{image.caption}</p>
                  </CardContent>
                </Card>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section id="kom-igang" className="py-16 sm:py-24">
        <div className="mx-auto w-full max-w-6xl px-4 sm:px-6 lg:px-8">
          <Reveal>
            <Card className="rounded-3xl border-border/80 bg-secondary text-secondary-foreground shadow-sm">
              <CardContent className="grid gap-8 p-8 sm:p-10 lg:grid-cols-[1.05fr_0.95fr] lg:items-center">
                <div className="space-y-5">
                  <Badge className="w-fit rounded-full bg-accent text-accent-foreground">Testa pingpong idag</Badge>
                  <h2 className="text-3xl font-semibold tracking-tight sm:text-4xl">
                    Börja med ett bord, ett racket och en första bollväxling.
                  </h2>
                  <p className="max-w-2xl text-secondary-foreground/85">
                    Du behöver inte vänta på perfekt nivå. Starta enkelt, spela ofta och bygg din teknik steg för steg.
                  </p>
                </div>

                <div className="space-y-3 rounded-2xl border border-white/15 bg-background/5 p-5">
                  <p className="inline-flex items-center gap-2 text-sm font-semibold">
                    <Sparkles className="h-4 w-4 text-accent" />
                    Din nästa serv är bara ett klick bort
                  </p>
                  <Button asChild size="lg" className="w-full rounded-full">
                    <a href="mailto:hej@pingpong.se?subject=Jag%20vill%20börja%20spela%20pingpong">
                      Börja spela
                      <ArrowRight className="h-4 w-4" />
                    </a>
                  </Button>

                  <Dialog>
                    <DialogTrigger asChild>
                      <Button
                        variant="secondary"
                        size="lg"
                        className="w-full rounded-full bg-background/90 text-secondary hover:bg-background"
                      >
                        Se 7-dagars startplan
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="rounded-2xl">
                      <DialogHeader>
                        <DialogTitle>7 dagar till trygg pingpongstart</DialogTitle>
                        <DialogDescription>
                          En enkel demoplan för dig som vill komma igång snabbt och spela med bättre flyt.
                        </DialogDescription>
                      </DialogHeader>
                      <ul className="space-y-2 text-sm text-muted-foreground">
                        <li className="inline-flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-primary" />
                          Dag 1–2: Grepp, serve och kontroll
                        </li>
                        <li className="inline-flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-primary" />
                          Dag 3–4: Fotarbete och placering
                        </li>
                        <li className="inline-flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-primary" />
                          Dag 5–7: Små matcher och speltempo
                        </li>
                      </ul>
                      <DialogFooter>
                        <DialogClose asChild>
                          <Button variant="outline">Stäng</Button>
                        </DialogClose>
                        <DialogClose asChild>
                          <Button asChild>
                            <Link href="/#utrustning">Till utrustning</Link>
                          </Button>
                        </DialogClose>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardContent>
            </Card>
          </Reveal>
        </div>
      </section>

      <div className="fixed inset-x-0 bottom-4 z-40 px-4 sm:hidden">
        <Button asChild size="lg" className="h-12 w-full rounded-full shadow-lg shadow-primary/20">
          <Link href="/#kom-igang">Börja spela</Link>
        </Button>
      </div>

      <BicycleWheelOverlay />
    </div>
  );
}