"use client"

import PricingPage from "../pricing-page"

export default function SyntheticV0PageForDeployment() {
  return <PricingPage />
}