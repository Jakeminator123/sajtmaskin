
import { Mail, MoveUpRight } from "lucide-react";
import Link from "next/link"

const footerLinks = [
  { label: "Fördelar", href: "/#fordelar" },
  { label: "Utrustning", href: "/#utrustning" },
  { label: "Regler", href: "/#regler" },
  { label: "Galleri", href: "/#galleri" },
  { label: "Börja spela", href: "/#kom-igang" },
];

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-card/50">
      <div className="mx-auto grid w-full max-w-6xl gap-10 px-4 py-12 sm:px-6 lg:grid-cols-3 lg:px-8">
        <div className="space-y-3">
          <h2 className="text-xl font-semibold">Mer om pingpong</h2>
          <p className="max-w-sm text-sm text-muted-foreground">
            Pingpong är snabbt, socialt och lätt att börja med. En boll, två racket och några minuter räcker för
            att få upp pulsen och ha kul.
          </p>
        </div>

        <nav aria-label="Sidlänkar" className="space-y-2">
          <h3 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">Snabblänkar</h3>
          <ul className="space-y-1">
            {footerLinks.map((item) => (
              <li key={item.href}>
                <Link
                  href={item.href}
                  className="group inline-flex items-center gap-1 rounded-md py-1 text-sm text-foreground/90 transition-colors hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                >
                  {item.label}
                  <MoveUpRight className="h-3.5 w-3.5 transition-transform duration-200 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <div className="space-y-3">
          <h3 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">Kontakt</h3>
          <a
            href="mailto:hej@pingpong.se"
            className="inline-flex items-center gap-2 rounded-md text-sm text-foreground transition-colors hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            <Mail className="h-4 w-4" />
            hej@pingpong.se
          </a>
          <p className="text-xs text-muted-foreground">© {new Date().getFullYear()} Pingpong. Spela för glädjen.</p>
        </div>
      </div>
    </footer>
  );
}

export default SiteFooter;
