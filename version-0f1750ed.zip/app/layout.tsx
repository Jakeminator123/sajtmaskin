import type { Metadata } from "next";
import { Inter, Sora } from "next/font/google";
import type { ReactNode } from "react";

import { Analytics } from "@vercel/analytics/next";
import { ThemeProvider } from "next-themes";

import OceanSwimmerOverlay from "@/components/ocean-swimmer-overlay";
import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";
import { Button } from "@/components/ui/button";
import { siteConfig } from "@/lib/site-data";

import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-sans",
});

const sora = Sora({
  subsets: ["latin"],
  variable: "--font-display",
});

export const metadata: Metadata = {
  title: {
    default: siteConfig.name,
    template: "%s | Kapten Krabbas Surfskola",
  },
  description: siteConfig.description,
  metadataBase: new URL(siteConfig.url),
  keywords: [...siteConfig.keywords],
  alternates: {
    canonical: "/",
  },
  openGraph: {
    title: siteConfig.name,
    description: siteConfig.description,
    url: siteConfig.url,
    siteName: siteConfig.name,
    locale: "sv_SE",
    type: "website",
    images: [
      {
        url: "/opengraph-image",
        width: 1200,
        height: 630,
        alt: "Kapten Krabbas Surfskola i Tylösand",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: siteConfig.name,
    description: siteConfig.description,
    images: ["/opengraph-image"],
  },
};

const organizationJsonLd = {
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  name: siteConfig.name,
  description: siteConfig.description,
  url: siteConfig.url,
  telephone: siteConfig.phoneDisplay,
  email: siteConfig.email,
  image: `${siteConfig.url}/opengraph-image`,
  address: {
    "@type": "PostalAddress",
    addressLocality: "Tylösand",
    addressRegion: "Halland",
    addressCountry: "SE",
  },
  areaServed: ["Tylösand", "Halmstad"],
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="sv" suppressHydrationWarning>
      <body
        className={`${inter.variable} ${sora.variable} min-h-screen bg-background text-foreground antialiased`}
      >
        <ThemeProvider attribute="class" defaultTheme="light" forcedTheme="light" enableSystem={false}>
          <noscript>
            <style>{`[data-animate],[data-stagger] > *{opacity:1!important;transform:none!important}`}</style>
          </noscript>
          <script
            type="application/ld+json"
            dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationJsonLd) }}
          />
          <a
            href="#main-content"
            className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[60] focus:rounded-full focus:bg-primary focus:px-4 focus:py-2 focus:text-primary-foreground focus:outline-none"
          >
            Hoppa till innehållet
          </a>

          <SiteHeader />
          <main id="main-content" className="relative pb-28 md:pb-0">
            {children}
          </main>
          <SiteFooter />
          <OceanSwimmerOverlay />

          <div className="pointer-events-none fixed inset-x-4 bottom-4 z-50 md:hidden">
            <Button
              asChild
              className="pointer-events-auto h-12 w-full rounded-full shadow-2xl shadow-primary/25"
            >
              <a href={siteConfig.phoneHref}>Ring oss • {siteConfig.phoneDisplay}</a>
            </Button>
          </div>

          <Analytics />
        </ThemeProvider>
      </body>
    </html>
  );
}