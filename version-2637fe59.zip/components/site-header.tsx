import Link from "next/link";
import { CircleDot, Menu } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetClose,
  SheetContent,
  SheetDescription,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";

const navItems = [
  { label: "Hem", href: "/" },
  { label: "Fördelar", href: "/#fordelar" },
  { label: "Utrustning", href: "/#utrustning" },
  { label: "Regler", href: "/#regler" },
  { label: "Galleri", href: "/#galleri" },
];

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-50 border-b border-border/70 bg-background/90 backdrop-blur supports-[backdrop-filter]:bg-background/80">
      <div className="mx-auto flex h-16 w-full max-w-6xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link href="/" className="group flex items-center gap-2 rounded-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
          <span className="grid h-9 w-9 place-items-center rounded-full bg-primary text-primary-foreground transition-transform duration-300 motion-safe:group-hover:scale-105">
            <CircleDot className="h-4 w-4" />
          </span>
          <div className="flex flex-col leading-none">
            <span className="text-sm font-semibold sm:text-base">Pingpong</span>
            <span className="text-xs text-muted-foreground">Kom igång snabbt</span>
          </div>
        </Link>

        <nav className="hidden items-center gap-1 md:flex">
          {navItems.map((item) => {
            const isActive = item.href === "/";
            return (
              <Link
                key={item.href}
                href={item.href}
                aria-current={isActive ? "page" : undefined}
                className={`rounded-full px-4 py-2 text-sm transition-colors ${
                  isActive
                    ? "bg-primary/10 font-semibold text-primary"
                    : "text-foreground/80 hover:bg-muted hover:text-foreground"
                }`}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="hidden items-center gap-2 md:flex">
          <Badge variant="secondary" className="rounded-full bg-accent/15 text-accent-foreground">
            Nybörjarvänligt
          </Badge>
          <Button asChild className="rounded-full">
            <Link href="/#kom-igang">Börja spela</Link>
          </Button>
        </div>

        <Sheet>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon" className="rounded-full md:hidden" aria-label="Öppna meny">
              <Menu className="h-5 w-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="w-[85vw] max-w-xs bg-card">
            <SheetTitle className="sr-only">Mobil navigering</SheetTitle>
            <SheetDescription className="sr-only">
              Välj en sektion för att läsa mer om pingpong och komma igång.
            </SheetDescription>

            <div className="mt-8 space-y-2">
              {navItems.map((item) => (
                <SheetClose asChild key={item.href}>
                  <Link
                    href={item.href}
                    className={`block rounded-xl px-4 py-3 text-base transition-colors ${
                      item.href === "/"
                        ? "bg-primary/10 font-semibold text-primary"
                        : "text-foreground hover:bg-muted"
                    }`}
                  >
                    {item.label}
                  </Link>
                </SheetClose>
              ))}
            </div>

            <div className="mt-6 border-t border-border pt-6">
              <SheetClose asChild>
                <Button asChild className="w-full rounded-full">
                  <Link href="/#kom-igang">Börja spela</Link>
                </Button>
              </SheetClose>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  );
}

export default SiteHeader;
