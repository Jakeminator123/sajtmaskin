import type { Metadata } from "next";
import Link from "next/link";
import { CloudSun, Compass, LifeBuoy, Mail, MapPin, Phone, ShieldCheck, Users, Waves, Wind } from "lucide-react";

import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { siteConfig } from "@/lib/site-data";

export const metadata: Metadata = {
  title: "Support",
  description:
    "Svar på vanliga frågor om surfkurser, väder, utrustning och gruppupplägg hos Kapten Krabbas Surfskola i Tylösand.",
  alternates: {
    canonical: "/support",
  },
};

const supportCards = [
  {
    title: "Inför lektionen",
    description:
      "Ta med badkläder, handduk, vatten och gott humör. Vi löser resten utan att du behöver dyka upp med egen mast.",
    icon: ShieldCheck,
  },
  {
    title: "Väder & vind",
    description:
      "Vi anpassar passet efter förhållandena. Havet får gärna vara piggt, men säkerheten får alltid sista ordet.",
    icon: CloudSun,
  },
  {
    title: "Grupper & privat",
    description:
      "Kompisgäng, familjer eller extra fokus med privatpass? Ring eller mejla så styr vi upp ett upplägg som passar.",
    icon: Users,
  },
  {
    title: "Hitta hit",
    description:
      "Vi håller till i Tylösand, Halmstad. Skriv eller ring om du vill ha tydlig mötespunkt så slipper du irra runt med bräddrömmar.",
    icon: MapPin,
  },
] as const;

const supportFaqs = [
  {
    question: "Var brukar vi ses i Tylösand?",
    answer:
      "Vi skickar tydlig mötespunkt när du hör av dig. Oftast håller vi oss nära stranden där förhållandena är som bäst för just dagens pass.",
  },
  {
    question: "Kan jag låna våtdräkt och surfbräda?",
    answer:
      "Ja. För de flesta pass ordnar vi utrustningen, så du slipper komma släpande som en egen liten surfbutik.",
  },
  {
    question: "Hur vet jag om Nybörjarbris räcker för mig?",
    answer:
      "Om du är ny på surfing eller bara vill ha en lugn och trygg start är Nybörjarbris rätt kurs. Är du osäker, ring oss så pekar vi ut rätt farled.",
  },
  {
    question: "Kan ni ordna något för ett mindre sällskap?",
    answer:
      "Absolut. Vi gillar små grupper där alla faktiskt får uppmärksamhet. Hör av dig så pratar vi ihop ett upplägg utan krångel.",
  },
] as const;

export default function SupportPage() {
  return (
    <div className="px-4 py-10 sm:px-6 sm:py-14 lg:px-8 lg:py-16">
      <div className="mx-auto max-w-7xl space-y-10">
        <section className="grid gap-8 lg:grid-cols-[0.95fr_1.05fr] lg:items-center">
          <div className="space-y-5" data-animate>
            <Badge className="rounded-full border-primary/15 bg-primary/10 px-4 py-2 text-primary">
              Support & sjöklar hjälp
            </Badge>
            <h1 className="font-display text-4xl font-semibold tracking-tight text-balance sm:text-5xl">
              Svar på det mesta innan du ens hunnit få sand i skorna
            </h1>
            <p className="max-w-2xl text-lg leading-8 text-muted-foreground">
              Här samlar vi det viktigaste om utrustning, väder, grupper och hur du hittar rätt.
              Behöver du snabbare svar än så är telefon och mejl fortfarande vår favoritfarkost.
            </p>

            <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
              <Button asChild className="h-12 rounded-full px-6 text-base shadow-lg shadow-primary/20">
                <a href={siteConfig.phoneHref}>
                  <Phone className="mr-2 h-5 w-5" />
                  Ring oss
                </a>
              </Button>
              <Button
                asChild
                variant="outline"
                className="h-12 rounded-full border-primary/15 bg-background/80 px-6 text-base"
              >
                <a href={siteConfig.emailHref}>
                  <Mail className="mr-2 h-5 w-5" />
                  Mejla
                </a>
              </Button>
            </div>
          </div>

          <Card className="sea-panel rounded-[1.5rem] border-0" data-animate data-delay="1">
            <CardHeader>
              <Badge className="w-fit rounded-full border-primary/15 bg-background/80 px-3 py-1 text-primary">
                Snabb överblick
              </Badge>
              <CardTitle className="font-display text-2xl tracking-tight">
                Det viktigaste på ett bräde
              </CardTitle>
              <CardDescription>
                Kortversionen för dig som vill få koll utan att bläddra genom en hel sjömanacka.
              </CardDescription>
            </CardHeader>
            <CardContent className="grid gap-3 sm:grid-cols-2">
              <div className="rounded-[1.25rem] bg-secondary/60 p-4">
                <div className="flex items-center gap-2 text-sm font-medium">
                  <Waves className="h-4 w-4 text-primary" />
                  Nybörjare välkomna
                </div>
                <p className="mt-2 text-sm leading-6 text-muted-foreground">
                  Du behöver inte ha surfat tidigare för att kliva ombord hos oss.
                </p>
              </div>
              <div className="rounded-[1.25rem] bg-secondary/60 p-4">
                <div className="flex items-center gap-2 text-sm font-medium">
                  <Wind className="h-4 w-4 text-primary" />
                  Vädret styr tonen
                </div>
                <p className="mt-2 text-sm leading-6 text-muted-foreground">
                  Vi anpassar passet efter havet. Säkerheten går alltid först.
                </p>
              </div>
              <div className="rounded-[1.25rem] bg-secondary/60 p-4">
                <div className="flex items-center gap-2 text-sm font-medium">
                  <Compass className="h-4 w-4 text-primary" />
                  Personlig vägledning
                </div>
                <p className="mt-2 text-sm leading-6 text-muted-foreground">
                  Små grupper gör att varje deltagare får riktig hjälp, inte bara glada tillrop på håll.
                </p>
              </div>
              <div className="rounded-[1.25rem] bg-secondary/60 p-4">
                <div className="flex items-center gap-2 text-sm font-medium">
                  <LifeBuoy className="h-4 w-4 text-primary" />
                  Direkt kontakt
                </div>
                <p className="mt-2 text-sm leading-6 text-muted-foreground">
                  Ring eller mejla om något är oklart. Det går snabbare än att gissa sig fram.
                </p>
              </div>
            </CardContent>
          </Card>
        </section>

        <section className="grid gap-5 md:grid-cols-2 xl:grid-cols-4" data-stagger>
          {supportCards.map((item) => (
            <Card
              key={item.title}
              className="sea-panel rounded-[1.5rem] border-0 transition-all duration-200 hover:-translate-y-1 hover:shadow-lg"
            >
              <CardHeader className="space-y-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary">
                  <item.icon className="h-5 w-5" />
                </div>
                <div className="space-y-2">
                  <CardTitle className="font-display text-2xl tracking-tight">{item.title}</CardTitle>
                  <CardDescription>{item.description}</CardDescription>
                </div>
              </CardHeader>
            </Card>
          ))}
        </section>

        <section className="grid gap-8 lg:grid-cols-[1fr_0.92fr]">
          <div className="space-y-5" data-animate>
            <Badge className="rounded-full border-primary/15 bg-background/80 px-4 py-2 text-primary">
              Vanligt på supporten
            </Badge>
            <h2 className="font-display text-3xl font-semibold tracking-tight text-balance sm:text-4xl">
              Fler frågor som ofta flyter in
            </h2>
            <Card className="sea-panel rounded-[1.5rem] border-0">
              <CardContent className="p-2 sm:p-3">
                <Accordion type="single" collapsible className="w-full">
                  {supportFaqs.map((item) => (
                    <AccordionItem
                      key={item.question}
                      value={item.question}
                      className="rounded-[1.25rem] border-0 px-3"
                    >
                      <AccordionTrigger className="text-left text-base font-medium hover:no-underline">
                        {item.question}
                      </AccordionTrigger>
                      <AccordionContent className="pb-4 pr-2 text-sm leading-7 text-muted-foreground">
                        {item.answer}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-5" data-stagger>
            <Card className="sea-panel rounded-[1.5rem] border-0">
              <CardHeader>
                <CardTitle className="font-display text-2xl tracking-tight">Kort väg tillbaka</CardTitle>
                <CardDescription>
                  Vill du kika på kurspaketen igen eller läsa om besättningen? Hemsidan ligger bara ett klick bort.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button asChild className="h-11 w-full rounded-full">
                  <Link href="/">Till startsidan</Link>
                </Button>
                <Button
                  asChild
                  variant="outline"
                  className="h-11 w-full rounded-full border-primary/15 bg-background/80"
                >
                  <Link href="/#kurser">Se kurserna</Link>
                </Button>
              </CardContent>
            </Card>

            <Card className="sea-panel-strong rounded-[1.5rem] border-0 text-primary-foreground">
              <CardHeader>
                <CardTitle className="font-display text-2xl tracking-tight">
                  Kontakt från land eller brygga
                </CardTitle>
                <CardDescription className="text-primary-foreground/82">
                  Vi föredrar tydliga raka puckar: ring eller mejla så hjälper vi dig snabbt vidare.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <a
                  href={siteConfig.phoneHref}
                  className="flex items-center gap-3 rounded-[1.25rem] bg-background/12 px-4 py-3 text-sm transition-colors duration-200 hover:bg-background/16 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
                >
                  <Phone className="h-4 w-4" />
                  {siteConfig.phoneDisplay}
                </a>
                <a
                  href={siteConfig.emailHref}
                  className="flex items-center gap-3 rounded-[1.25rem] bg-background/12 px-4 py-3 text-sm transition-colors duration-200 hover:bg-background/16 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
                >
                  <Mail className="h-4 w-4" />
                  {siteConfig.email}
                </a>
                <div className="flex items-center gap-3 rounded-[1.25rem] bg-background/12 px-4 py-3 text-sm">
                  <MapPin className="h-4 w-4" />
                  {siteConfig.location}
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      </div>
    </div>
  );
}